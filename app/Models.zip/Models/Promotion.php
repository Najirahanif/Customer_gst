<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Promotion extends Model
{
    public $timestamps = false;
    protected $table = 'promotions';

    protected $fillable = [
        'name',
        'image',
        'status',
    ];
}
