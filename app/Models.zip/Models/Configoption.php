<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Configoption extends Model
{
    protected $table ='configoptions';
    protected $fillable =[
     'optionname',
    ];
}
