<?php
namespace App\Models;
use Eloquent;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

Class Settings extends Eloquent {
	protected $table='settings';

    protected $fillable = [
        'name',
        'about',
        'company',
        'email',
        'country',
        'password',
        'image',
        'phone',
        'address',
        'twitterlink',
        'facebooklink',
        'instagramlink',
        'youtubelink',
        'updated_at',
        'lastlogindate'

    ];
}
