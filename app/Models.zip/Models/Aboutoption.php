<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Aboutoption extends Model
{public $timestamps = false;
    protected $table = 'aboutoptions';

    protected $fillable = [
        'aboutid',
        'optionname',
        'optiondescription',
        'optionimage',

    ];
}
