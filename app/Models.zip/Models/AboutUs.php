<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AboutUs extends Model
{public $timestamps = false;
    protected $table = 'aboutus';

    protected $fillable = [
        'iamge',
    ];
}
