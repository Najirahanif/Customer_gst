<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Project extends Model
{public $timestamps = false;
    protected $table = 'projects';

    protected $fillable = [
        'name',
        'country',
        'state',
        'city',
        'phonenumber',
        'address',
        'image',
        'shopname',
        'weburl',
        'floor_plan_images',
        'status',
   
    ];
}
