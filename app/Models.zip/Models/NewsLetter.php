<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NewsLetter extends Model
{
    public $timestamps = false;
    protected $table = 'newsletters';

    protected $fillable = [
        'name',
        'slug',
        'subject',
        'discription',
        'status',
    ];
}
