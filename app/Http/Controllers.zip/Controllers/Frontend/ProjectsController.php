<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;
use App\Models\MainCategory;
use App\Models\Project;
class ProjectsController extends Controller {

    public function index(Request $request) {
        $selectedCategories = $request->input('category', null);
        $projectsQuery = Project::query()->where('deleted_at', '0')->where('status', 'active');
        $this->applyCategoryFilter($projectsQuery, $selectedCategories);
    
        $projects = $projectsQuery->get();
        $categoryname = null;
        if($selectedCategories){
            $category= MainCategory::find($selectedCategories);
            $categoryname=$category->name;
        }
        return view('site.project.index', compact('projects','categoryname'));
    }
    
    public function applyCategoryFilter($query, $categoryIds)
    {
        if (is_string($categoryIds)) {
            $categoryIds = explode(',', $categoryIds);
        }
    
        if (is_array($categoryIds)) {
            $query->where(function ($query) use ($categoryIds) {
                foreach ($categoryIds as $categoryId) {
                    $query->orWhereRaw("FIND_IN_SET(?, `category`)", [$categoryId]);
                }
            });
        }
    }
    
}
