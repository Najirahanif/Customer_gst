<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class ProjectInfoController extends Controller {

    public function index(Request $request) {
        $selectedProjectId = $request->input('projectID');
        // Retrieve project information
$selectedProjectId = $request->input('projectID');
$projectInfo = DB::table('projects')
    ->leftJoin('countries', 'projects.country', '=', 'countries.id')
    ->leftJoin('states', 'projects.state', '=', 'states.id')
    ->leftJoin('cities', 'projects.city', '=', 'cities.id')
    ->leftJoin('posts', 'projects.postname', '=', 'posts.id')
    ->leftJoin('maincategories', 'projects.category', '=', 'maincategories.id')
    ->select(
        'countries.name as country',
        'states.state as state',
        'cities.city as city',
        'projects.id as id',
        'projects.plotno as plotno',
        'projects.name as name',
        'projects.title as title',
        'projects.pincode as pincode',
        'countries.code as code',
        'projects.address as address',
        'projects.floor_plan_images as floor_plan_images',
        'projects.floor_plan_pdf as floor_plan_pdf',
        'projects.image as image',
        'projects.addinfo as addinfo',
        'projects.weburl as weburl',
        'maincategories.name as categoryname',
        'maincategories.id as categoryid',
        'posts.id as postid',
        'posts.name as postname',
        'projects.status as status'
    )
    ->where('projects.deleted_at', '0')
    ->where('projects.id', '=', $selectedProjectId)
    ->first();

    // Explode the addinfo value into an array
    $addinfoArray = explode(',', $projectInfo->addinfo);

    // Retrieve flat details associated with the addinfo values
    $flatDetails = DB::table('flatdetails')
        ->leftJoin('configoptions as floor_options', 'floor_options.id', '=', 'flatdetails.floor')
        ->leftJoin('configoptions as facing_options', 'facing_options.id', '=', 'flatdetails.facing')
        ->whereIn('flatdetails.id', $addinfoArray)
        ->select(
            'flatdetails.*',
            'floor_options.optionname as floor_name',
            'facing_options.optionname as facing_name'
        )
        ->get();
        // dd($projectInfo);
        return view('site.projectinfo.index', compact('projectInfo','flatDetails'));
    }

}
