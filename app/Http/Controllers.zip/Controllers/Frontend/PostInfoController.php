<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Post;
use App\Models\Configoption;

class PostInfoController extends Controller {
    public function index(Request $request) {
        $selectedPostId = $request->input('postID');
        $postInfo = Post::where('id', '=', $selectedPostId)->first();
        $postoptionsArray = explode(',', $postInfo->postoptions);
    
        $postoptions = [];
        foreach ($postoptionsArray as $id) {
            $configOptions = Configoption::where('id', '=', $id)->get();
            $postoptions[] = $configOptions;
        }
    
        return view('site.postinfo.index', compact('postInfo', 'postoptions'));
    }
    

}
