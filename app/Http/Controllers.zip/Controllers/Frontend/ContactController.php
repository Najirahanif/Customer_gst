<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request; 
use App\Models\Newsletter;
use App\Models\Contact;
use Illuminate\Support\Facades\Mail;
class ContactController extends Controller {

    public function index() {
        return view('site.contact.index');

    }
    public function submitForm(Request $request)
    {

        $mailData = [
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'message' => $request->input('message')
        ];
    
        $fromEmail = 'tharasasi333@gmail.com';
        $fromName = "sasi";
        $subject = "mail for user queries";
    
        $viewName = view()->exists('emails.contact_mail') ? 'emails.contact_mail' : 'emails.contact_mail';
    
        try {
            Mail::send($viewName, $mailData, function ($message) use ($request, $subject, $fromEmail, $fromName) {
                $message->to($request->input('email'))
                    ->subject($subject)
                    ->from($fromEmail, $fromName);
            });
        } catch (\Exception $e) {
            // Log the error or handle it in some other way
            // For example:
            // Log::error('Error sending email: ' . $e->getMessage());
            return redirect()->back()->withErrors(['email_error' => 'Failed to send email. Please try again.']);
        }
        
        // $contact = new Contact();
        // $contact->name = $request->input('name');
        // $contact->contact_number =  $request->input('contactNumber');
        // $contact->email =  $request->input('email');
        // $contact->message =  $request->input('message');
        // $contact->save();

        return response()->json(['message' => 'Your message has been submitted successfully!']);
    }
}
