<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;
use App\Models\Service;
class ServicesController extends Controller {

    public function index() {
        $service=Service::where('status','=','active')->get();
        return view('site.service.index',compact('service'));

    }
}
