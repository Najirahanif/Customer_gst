<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;
use App\Models\Testimonial;
use App\Models\Promotion;
use App\Models\Gallery;
use App\Models\Slider;
class HomeController extends Controller {

    public function home() {
        $slider = Slider::where('status', '=', 'active')->where('bannertype', '=', 'slider')->get();
        $banner1 = Slider::where('status', '=', 'active')->where('bannertype', '=', 'banner1')->first();
        $banner2 = Slider::where('status', '=', 'active')->where('bannertype', '=', 'banner2')->first();     
        $testimonial=Testimonial::where('status','=','active')->get();
        $gallery=Gallery::where('status','=','active')->get();
        $promotions = DB::table('promotions')
        ->leftJoin('configoptions', 'promotions.icon', '=', 'configoptions.id')
        ->where('promotions.status', '=', 'active')
        ->where('promotions.deleted_at', '=', '0')
        ->select('promotions.*', 'configoptions.optionname as icon_name')
        ->limit(3)
        ->get();
        $service = DB::table('services')
        ->leftJoin('configoptions', 'services.icon', '=', 'configoptions.id')
        ->where('services.status', '=', 'active')
        ->where('services.deleted_at', '=', '0')
        ->select('services.*', 'configoptions.optionname as icon_name')
        ->get();
        $allpost = DB::table('posts')
        ->leftJoin('configoptions', function ($join) {
            $join->on(DB::raw('FIND_IN_SET(configoptions.id, posts.postoptions)'), '>', DB::raw('0'));
        })
        ->where('posts.status', '=', 'active')
        ->groupBy('posts.id', 'posts.name', 'posts.image') 
        ->select('posts.id', 'posts.name', 'posts.image', DB::raw('GROUP_CONCAT(configoptions.optionname) as option_names'))
        ->get();
        // dd( $allpost);
        return view('site.home.index',compact('slider','banner1','banner2','testimonial','promotions','gallery','service','allpost'));
    }
}
