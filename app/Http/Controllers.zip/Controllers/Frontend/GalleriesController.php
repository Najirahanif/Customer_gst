<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;
use App\Models\Gallery;
class GalleriesController extends Controller {

    public function index() {
        $gallery=Gallery::where('status','=','active')->get();
        return view('site.gallery.index',compact('gallery'));

    }
}
