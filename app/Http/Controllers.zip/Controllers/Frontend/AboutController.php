<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\AboutUs;
use App\Models\Aboutoption;
use App\Models\Gallery;

class AboutController extends Controller {

    public function index() {
        $aboutusinfo = DB::table('aboutoptions')
        ->leftJoin('aboutus', 'aboutoptions.aboutid', '=', 'aboutus.id')
            ->select('aboutoptions.*', 'aboutus.image as aboutimage')            
            ->get();
        $gallery=Gallery::where('status','=','active')->get();
        return view('site.about.index',compact('aboutusinfo','gallery'));
        
    }

    public function aboutus() {
        $aboutusinfo = DB::table('aboutoptions')
        ->leftJoin('aboutus', 'aboutoptions.aboutid', '=', 'aboutus.id')
            ->select('aboutoptions.*', 'aboutus.image as aboutimage')            
            ->get();
        return view('admin.about.index',compact('aboutusinfo'));
    }

    public function updateaboutus(Request $request)
    {
        $input = $request->all();
        $configInfo = AboutUs::find(1);
        $addMoreInputFields = $request->input('addMoreInputFields');
        $aboutimagePath = 'uploads/images/aboutus';
    
        // Handling About Image
        if ($request->hasFile('aboutimage')) {
            $aboutimg = $request->file('aboutimage');
            $aboutimgext = $aboutimg->getClientOriginalExtension();
            $filename = rand(100000, 999999);
            $aboutfile = $filename . '.' . $aboutimgext;
            $aboutimg->move($aboutimagePath, $aboutfile);
            $aboutsettinglink = $aboutimagePath . '/' . $aboutfile;
            $configInfo->image = $aboutsettinglink;
        }
    
        // Save About Image
        $configInfo->save();
    
        // Handling About Option Images
        foreach ($addMoreInputFields as $key => $value) {
            $optionId = $value['aboutoption_id']?? null; 
            $optionName = $value['name']?? null;
            $optionDescription = $value['description']?? null;
            
            if (!empty($optionName)) {
                // Check if a new image is uploaded
                if ($request->hasFile("addMoreInputFields.$key.image")) {
                    // Process the new image
                    $optionimg = $request->file("addMoreInputFields.$key.image");
                    $optionimgext = $optionimg->getClientOriginalExtension();
                    $optionfilename = rand(100000, 999999);
                    $optionfile = $optionfilename . '.' . $optionimgext;
                    $optionimg->move("$aboutimagePath/option", $optionfile);
                    $optionsettinglink = "$aboutimagePath/option/$optionfile";
                } else {
                    // Use the existing image path if no new image is uploaded
                    $optionsettinglink = $value['existing_image'];
                }
    
                // Find or create Aboutoption model
                $aboutOption = Aboutoption::find($optionId);
                if ($aboutOption) {
                    // If Aboutoption exists, update its attributes
                    $aboutOption->optionname = $optionName;
                    $aboutOption->optiondescription = $optionDescription;
                    $aboutOption->optionimage = $optionsettinglink;
                    $aboutOption->save();
                } else {
                    // If Aboutoption doesn't exist, create a new one
                    Aboutoption::create([
                        'aboutid' => $configInfo->id,
                        'optionname' => $optionName,
                        'optiondescription' => $optionDescription,
                        'optionimage' => $optionsettinglink
                    ]);
                }
            }
        }
    
        // Success flash message
        Session::flash('messageType', 'success');
        Session::flash('message', 'Config Successfully Updated!');
    
        // Redirect back to config index
        return redirect()->route('admin.about');
    }
    
    public function deleteAboutoption(Request $request) {
        $aboutoptionId = $request->input('aboutoption_id');
        // Delete the Aboutoption with the provided ID
        Aboutoption::destroy($aboutoptionId);
        return response()->json(['success' => true]);
    }
    
}
