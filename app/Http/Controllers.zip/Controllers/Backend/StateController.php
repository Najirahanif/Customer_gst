<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\State;
use App\Models\Country;
use App\Models\City;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File;
use Carbon\Carbon;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\StateExport;
use PDF;

class StateController extends Controller
{

    public function index()
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $states = $this->getStateList();
            $alldata = DB::table('states')
                ->join('countries', 'states.country', '=', 'countries.id')
                ->select(
                    'countries.name as country',
                    'states.id as id',
                    'states.state as state',
                    'states.status as status'
                )
                ->where('states.deleted_at', '0')
                ->orderBy('states.id', 'desc')
                ->get();
    
            return view('admin.master.state.index', compact('alldata'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }


    public function getStateList()
    {
        return State::orderBy('id', 'desc')->where('deleted_at', '0')->get();
    }
    

    public function addstate()
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $countryshow = Country::where('status', 'active')->get();
            return view('admin.master.state.addstate', compact('countryshow'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }


    public function postaddstate(Request $request)
    {
        $input = $request->all();
       
        $result = $this->create($input);
        Session::flash('messageType', 'success');
        Session::flash('message', 'State successfully added');
        return redirect()->route('admin.statelist');
    }

    public function create(array $input)
    {
        $state = new State;
        $state->country = $input['country'];
        $state->state = ucwords(strtolower($input['state']));
        $state->created_at = Carbon::now();
        $state->updated_at = Carbon::now();
        $state->save();
        return 1;
    }


    public function statechangestatus(Request $request)
    {
        $id = $request->input('id');
        $state = State::find($id);
        if ($state) {
            $state->status = $state->status == 'inactive' ? 'active' : 'inactive';
            $state->save();
            return response()->json(["message" => 'success', 'status' => $state->status === 'active' ? 1 : 2]);
        }
        return response()->json(["message" => 'Failed to change status']);
    }


    public function softdeletestate(Request $request)
    {
        $id = $request->input('id');
        $state = State::find($id);
    
        $city = City::where('state', $id)->exists();
    
    
        if ($city) {
            session()->flash('messageType', 'error');
            session()->flash('message', 'Opps!, This State is assosiated with City');
            return redirect()->route('admin.statelist');
        } else {
            if (!$state) {
                session()->flash('messageType', 'error');
                session()->flash('message', 'State not found.');
                return redirect()->route('admin.deletestate');
            }
            $state->deleted_at = '1';
            $state->save();
            session()->flash('messageType', 'success');
            session()->flash('message', 'State temporarily deleted!');
            return redirect()->route('admin.statelist');
        }
    }
    
 


    
    public function editstate($id)
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $stateinfo = State::find($id);
            $country = Country::where('status', 'active')->get();
            return view('admin.master.state.editstate', compact('stateinfo', 'country'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }
    

    public function updatestate(Request $request)
    {
        $input = $request->all();
        $result = $this->update($input);
        if ($result == 1) {
            Session::flash('messageType', 'success');
            Session::flash('message', 'State successfully updated');
        }
        return redirect()->route('admin.statelist');
    }

    public function update(array $input)
    {
        $id = $input['stateid'];
        $state = State::find($id);
        
        if ($state) {
            $state->country = $input['country'];
            $state->state = ucwords(strtolower($input['state']));
        
            if ($state->isDirty()) {
                $state->updated_at = Carbon::now();
                $state->save();
                return 1;
            } else {
                return 0;
            }
        } else {
            return 0; 
        }
    }
          

    public function stateTrashList()
    {
        $alldata = DB::table('states')
            ->join('countries', 'states.country', '=', 'countries.id')
            ->select(
                'countries.name as country',
                'states.id as id',
                'states.state as state',
                'states.status as status'
            ) 
            ->where('states.deleted_at', '1')
            ->orderBy('states.id', 'desc')
            ->get();
    
        return view('admin.trash.state.index', compact('alldata'));
    }


    

    public function restoreState()
    {
        $id = request('id');
        $state = State::find($id);
        if ($state) {
            $state->deleted_at = '0';
            $state->save();
            Session::flash('messageType', 'success');
            Session::flash('message', 'State restore successfully!');
            return redirect()->route('admin.statelist');
        }
    }


    public function statepdf()
    {
        $alldata = DB::table('states')
            ->join('countries', 'states.country', '=', 'countries.id')
            ->select(
                'countries.name as country',
                'states.id as id',
                'states.state as state',
                'states.status as status'
            ) 
            ->where('states.deleted_at', '0')
            ->orderBy('states.id', 'desc')
            ->get();

        $pdf = PDF::loadView('admin.master.state.exportstate', compact('alldata'));
        return $pdf->download('exportstate' . time() . rand(99, 9999) .'.pdf');
    }


    public function exportstatecsv()
    {
        $alldata = DB::table('states')
            ->join('countries', 'states.country', '=', 'countries.id')
            ->select(
                'countries.name as country',
                'states.id as id',
                'states.state as state',
                'states.status as status'
            ) 
            ->where('states.deleted_at', '0')
            ->orderBy('states.id', 'desc')
            ->get();

        $export = new StateExport($alldata);
        return Excel::download($export, 'exportstate' . time() . rand(99, 9999) . '.csv');
    }
}
