<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\DB;
use App\Models\Project;
use App\Models\Country;
use App\Models\MainCategory;
use App\Models\State;
use App\Models\City;
use App\Models\Post;
use App\Models\FlatDetails;
use Carbon\Carbon;
use App\Exports\ProjectExport;
use View;
use PDF;

class ProjectController extends Controller
{

    public function index() {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
        // $projectlist = $this->getprojectlist();
        $projectlist = DB::table('projects')
        ->join('maincategories', 'projects.category', '=', 'maincategories.id')
        ->select(
            'projects.id as id',
            'projects.name as name',
            'projects.title as title',
            'projects.address as address',
            'projects.plotno as plotno',
            'projects.image as image',
            'projects.weburl as weburl',
            'maincategories.name as categroryname',
            'projects.status as status'
            )
        ->where('projects.deleted_at', '0')
        ->orderBy('projects.id', 'desc')->get();
        // dd( $projectlist);
        return view('admin.project.index', compact('projectlist'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }
      
    public function getprojectlist() {
        return Project::orderBy('id', 'desc')->where('deleted_at','0')->get();
    }

    public function addproject()
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $country = Country::where("status" , "=", "active")->where("deleted_at", "=", "0")->get();
            $statelist = State::where("status" , "=", "active")->where("deleted_at", "=", "0")->get();
            $citylist = City::where("status" , "=", "active")->where("deleted_at", "=", "0")->get();
            $postlist = Post::where("status" , "=", "active")->where("deleted_at", "=", "0")->get();
            $categorylist = MainCategory::where("status" , "=", "active")->where("deleted_at", "=", "0")->get();        
            $flatdetails = FlatDetails::where("status" , "=", "active")->get();
            return view('admin.project.addproject', compact('country','statelist','citylist','postlist','categorylist','flatdetails'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function postaddproject(Request $request)
    {
        $input = $request->all();
        // dd($input);
        $addinfo = isset($input['additionalinfo']) ? $input['additionalinfo'] : null;
        $serializedAddinfo = is_array($addinfo) ? implode(',', $addinfo) : '';
        $imagePath = 'uploads/images/project';
        $imageData = []; // Initialize imageData as an empty array
    
        // Handle main image upload
        if ($request->hasFile('image')) {
            $logoimg = $request->file('image');
            $logoext = $logoimg->getClientOriginalExtension();
            $filename = rand(100000, 999999);
            $file = $filename . '.' . $logoext;
            $logoimg->move($imagePath, $file);
            $settinglink = $imagePath . '/' . $file;
            $input['image'] = $settinglink;
        }
        if ($request->hasFile('planPdf')) {
            $pdf = $request->file('planPdf');
            $pdfExtension = $pdf->getClientOriginalExtension();
            $pdfFilename = rand(100000, 999999) . '.' . $pdfExtension;
            $pdf->move('uploads/pdf', $pdfFilename);
            $pdfPath = 'uploads/pdf/' . $pdfFilename;
            $input['floor_plan_pdf'] = $pdfPath;
        }
        $imageData = [];

        if ($request->hasFile('floorplanimages')) {
            foreach ($request->file('floorplanimages') as $image) {
                $randomNumber = rand(100000, 999999);
                $fileExtension = $image->getClientOriginalExtension();
                $newFilename = $randomNumber . '.' . $fileExtension;
                $image->move('uploads/images/project/floorplanimages', $newFilename);

                $imageData[] = 'uploads/images/project/floorplanimages/' . $newFilename;
            }
        }
    
        $result = $this->create($input, $imageData ,$serializedAddinfo);
    
        session()->flash('messageType', 'success');
        session()->flash('message', 'project successfully added');
        return redirect()->route('admin.projectlist');
    }
    
    public function create(array $input, $imageData,$serializedAddinfo)
    {
        $project = new Project;
        $project->name = ucwords(strtolower($input['name']));
        $project->title = ucwords(strtolower($input['title']));
        $project->plotno = $input['plotno'];
        $project->country = $input['country'];
        $project->state = $input['state'];
        $project->city = $input['city'];
        $project->pincode = $input['pincode'];
        $project->address = $input['address'];
        $project->category = $input['category'];
        $project->image = $input['image'];
        $project->floor_plan_images = json_encode($imageData);
        $project->weburl = $input['location'];
        $project->addinfo = $serializedAddinfo;
        $project->floor_plan_pdf = $input['planPdf'] ?? null;
        $project->created_at = Carbon::now();
        $project->updated_at = Carbon::now();
        $project->save();
        return 1;
    }
    

    public function deleteproject(Request $request)
    {
        $id = $request->input('id');
        $project = Project::find($id);
        if (!$project) {
            session()->flash('messageType', 'fail');
            session()->flash('message', 'project not found.');
            return redirect()->route('admin.projectlist');
        }
        $project->delete();
        session()->flash('messageType', 'success');
        session()->flash('message', 'project Permanetly deleted!');
        return redirect()->route('admin.projectlist');
    }
    
    public function projectstatuschange(Request $request)
    {
        $id = $request->input('id');
        $project = Project::find($id);
        // echo "<pre>";print_r($project);exit;
        if ($project) {
            $project->status = $project->status == 'inactive' ? 'active' : 'inactive';
            $project->save();
            return response()->json(["message" => 'success', 'status' => $project->status === 'active' ? 1 : 2]);
        }
        return response()->json(["message" => 'Failed to change']);
    }

    // postupdateproject
    public function projectview($id){
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $project = DB::table('projects')
                ->leftJoin('countries', 'projects.country', '=', 'countries.id')
                ->leftJoin('states', 'projects.state', '=', 'states.id')
                ->leftJoin('cities', 'projects.city', '=', 'cities.id')
                ->leftJoin('maincategories', 'projects.category', '=', 'maincategories.id')
                ->select(
                    'countries.name as country',
                    'states.state as state',
                    'cities.city as city',
                    'projects.id as id',
                    'projects.plotno as plotno',
                    'projects.name as name',
                    'projects.title as title',
                    'projects.pincode as pincode',
                    'countries.code as code',
                    'projects.address as address',
                    'projects.floor_plan_images as floor_plan_images',
                    'projects.floor_plan_pdf as floor_plan_pdf',
                    'projects.image as image',
                    'projects.weburl as weburl',
                    'maincategories.id as categoryid',
                    'maincategories.name as category',
                    'projects.status as status'
                )
                ->where('projects.deleted_at', '0')
                ->where('projects.id', '=', $id)
                ->orderBy('projects.id', 'desc')
                ->first();
// dd( $project);
        return view('admin.project.viewproject', compact('project'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }
    
    }

    public function editproject($id){
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $project = Project::find($id);
            $country= Country::where('status','=','active')->where("deleted_at", "=", "0")->get();
            $statelist= State::where('status','=','active')->where("deleted_at", "=", "0")->get();
            $citylist= City::where('status','=','active')->where("deleted_at", "=", "0")->get();
            $postlist = Post::where("status" , "=", "active")->where("deleted_at", "=", "0")->get();
            $categorylist = MainCategory::where("status" , "=", "active")->where("deleted_at", "=", "0")->get();
            $flatdetails = FlatDetails::where("status" , "=", "active")->get();
            $flatdetailsIds=explode(',', $project->addinfo);
            // dd($flatdetailsIds);
            return view('admin.project.editproject', compact('project','country','statelist','citylist','postlist','categorylist','flatdetails','flatdetailsIds'));
    
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }
    public function postupdateproject(Request $request) {
        $input = $request->all();
        $addinfo = isset($input['additionalinfo']) ? $input['additionalinfo'] : null;
        $serializedAddinfo = is_array($addinfo) ? implode(',', $addinfo) : '';
        if ($request->hasFile('floor_plan_pdf')) {
            $pdf = $request->file('floor_plan_pdf');
            $pdfExtension = $pdf->getClientOriginalExtension();
            $pdfFilename = rand(100000, 999999) . '.' . $pdfExtension;
            $pdf->move('uploads/pdf', $pdfFilename);
            $pdfPath = 'uploads/pdf/' . $pdfFilename;
            $input['floor_plan_pdf'] = $pdfPath;
        }
        $result = $this->update($input,$serializedAddinfo);
        if($result == 1) {
            session()->flash('messageType', 'success');
            session()->flash('message', 'project successfully updated');
        }
        return redirect()->route('admin.projectlist');
    }
    
    public function update(array $input,$serializedAddinfo) {
        $id = $input['projectid'];
        $project = Project::find($id);
    
        if (!$project) {
            return 0; // project not found
        }
    
        $project->name = ucwords(strtolower($input['name']));
        $project->title = ucwords(strtolower($input['title']));
        $project->country = $input['country'];
        $project->state = $input['state'];
        $project->city = $input['city'];
        $project->pincode = $input['pincode'];
        $project->address = $input['address'];
        $project->category = $input['category'];
        $project->plotno = $input['plotno'];
        $project->weburl = $input['location'];
        $project->floor_plan_pdf = $input['floor_plan_pdf'] ?? null;
        $project->addinfo = $serializedAddinfo;
    
        // Handle main image upload
        if (request()->hasFile('image') && request()->file('image')->isValid()) {
            $imagePath = 'uploads/images/project';
            $logoimg = request()->file('image');
            $logoext = $logoimg->getClientOriginalExtension();
            $filename = rand(100000, 999999);
            $file = $filename . '.' . $logoext;
            $logoimg->move($imagePath, $file);
            $settinglink = $imagePath . '/' . $file;
            $project->image = $settinglink;
        }
    
        // Handle additional images upload
        if (request()->hasFile('files')) {
            $imageData = [];
    
            foreach (request()->file('files') as $image) {
                if ($image->isValid()) {
                    $randomNumber = rand(100000, 999999);
                    $fileExtension = $image->getClientOriginalExtension();
                    $newFilename = $randomNumber . '.' . $fileExtension;
                    $image->move('uploads/images/project/floorplanimages/', $newFilename);
                    $imageData[] = 'uploads/images/project/floorplanimages/' . $newFilename;
                }
            }
    
            // Merge new images with existing images
            $existingImages = json_decode($project->floor_plan_images, true) ?? [];
            $imageData = array_merge($existingImages, $imageData);
            $project->floor_plan_images = json_encode($imageData);
        }
    
        // Handle image deletion
        if (isset($input['deleteImages']) && is_array($input['deleteImages'])) {
            $deletedImages = $input['deleteImages'];
            // Remove leading commas and trim spaces for each element
            $newImageArray = array_map(function ($value) {
                return trim($value, ', ');
            }, $deletedImages);

            // Decode the existing images from JSON
            $existingImages = json_decode($project->floor_plan_images, true) ?? [];
            // Split the string into an array using comma as the delimiter
            $imageArray = explode(',', $newImageArray[0]);
            // Delete files from the folder
            $allowedExtensions = ['jpg', 'jpeg', 'png', 'svg'];
            foreach ($imageArray as $deletedImage) {
                $filePath = public_path($deletedImage);

                // Get the file extension
                $fileExtension = pathinfo($filePath, PATHINFO_EXTENSION);
                // Check if the file has an allowed image extension
                if (in_array(strtolower($fileExtension), $allowedExtensions)) {
                    try {
                        if (file_exists($filePath)) {
                            unlink($filePath);
                            echo "File deleted: $filePath";
                        } else {
                            echo "File not found: $filePath";
                        }
                    } catch (\Exception $e) {
                        // Handle the exception, e.g., log it or output an error message
                        echo "Error deleting file: " . $e->getMessage();
                    }
                } else {
                    echo "File has an unsupported extension: $filePath";
                }
            }
            // Get the difference (existing images - deleted images)
            $newImagesArray = array_diff($existingImages, $imageArray);
            // Update the 'floor_plan_images' attribute with the modified image data
            $project->floor_plan_images = json_encode(array_values($newImagesArray));
        }

    
        // Save project data
        if ($project->isDirty()) {
            $project->updated_at = now();
            $project->save();
            return 1; // Successfully updated
        } else {
            return 0; // No changes to update
        }
    }
    
    public function projectpdf() {
        $project = DB::table('projects')
            ->leftJoin('maincategories', 'projects.category', '=', 'maincategories.id')
            ->select(
                'projects.id as id',
                'projects.name as name',
                'projects.title as title',
                'projects.pincode as pincode',
                'projects.plotno as plotno',
                'projects.address as address',
                'projects.image as image',
                'maincategories.name as categroryname',
                'projects.weburl as weburl',
                'projects.status as status'
            )
            ->where('projects.deleted_at', '0')
            ->orderBy('projects.id', 'desc')->get();
    
        // dd($project);
    
        $pdf = PDF::loadView('admin.project.exportproject', compact('project'));
        return $pdf->download('exportproject' . time() . rand(99, 9999) .'.pdf');
    }


    public function exportprojectcsv() {
        $project = DB::table('projects')
            ->leftJoin('maincategories', 'projects.category', '=', 'maincategories.id')
            ->select(
                'projects.id as id',
                'projects.name as name',
                'projects.title as title',
                'projects.pincode as pincode',
                'projects.address as address',
                'projects.image as image',
                'projects.weburl as weburl',
                'maincategories.name as categroryname',
                'projects.status as status'
            )
            ->where('projects.deleted_at', '0')
            ->orderBy('projects.id', 'desc')->get();
    
        $export = new ProjectExport($project);
        return Excel::download($export, 'Exportproject' . time() . rand(99, 9999) . '.csv');
    }

    
    }