<?php

namespace App\Http\Controllers\Backend;

use App\Exports\flatdetailsExport;
use App\Http\Controllers\Controller;
use App\Models\FlatDetails;
use Illuminate\Auth\Events\Validated;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Maatwebsite\Excel\Facades\Excel;
use View;
use PDF;

class FlatDetailsController extends Controller
{
    
    // flatdetails list
    public function index(){
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $flatdetailslist = DB::table('flatdetails')
            ->join('configoptions as floors', 'flatdetails.floor', '=', 'floors.id')
            ->join('configoptions as facings', 'flatdetails.facing', '=', 'facings.id')
            ->select(
                'flatdetails.*',
                'floors.optionname as floor',
                'facings.optionname as facing',
                )
            ->where('flatdetails.deleted_at', '0')
            ->orderBy('flatdetails.id', 'desc')->get();
        
            return view('admin.master.flatdetails.index',compact('flatdetailslist'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }
    

    // flatdetails add
    public function addflatdetails(){
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $floor = DB::table('configoptions')
            ->leftJoin('configs', 'configoptions.configid', '=', 'configs.id')
                ->select('configoptions.id as id', 'configoptions.optionname as optionname')            
                ->where('configs.slug', '=', 'floor')
                ->get();
            $facing = DB::table('configoptions')
            ->leftJoin('configs', 'configoptions.configid', '=', 'configs.id')
                ->select('configoptions.id as id', 'configoptions.optionname as optionname')            
                ->where('configs.slug', '=', 'facing')
                ->get();
            return view('admin.master.flatdetails.addflatdetails',compact('floor',"facing"));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }


    // post add flatdetails
    public function postaddflatdetails(Request $request){

        $input=$request->all();
        // dd($input);
        $result = $this->create($input);

        session()->flash('messageType','success');
        session()->flash('message', 'flatdetails successfully added');
        return redirect()->route('admin.flatdetailslist');
        
    }

    // adding the data to the datbase

    public function create(array $input){

        $flatdetails = new FlatDetails;
        $flatdetails->flatno=$input['flatno'];
        $flatdetails->area=$input['area'];
        $flatdetails->floor = $input['floor'];
        $flatdetails->rooms = $input['room'];
        $flatdetails->facing = $input['facing'];
        $flatdetails->flatstatus = $input['flatstatus'];
        $flatdetails->created_at = Carbon::now();
        $flatdetails->updated_at = Carbon::now();
        $flatdetails->save();
        return 1;
        
    }


    // status change

    public function statusChangeflatdetails(Request $request){
        $id=$request->input('id');
        $flatdetailstatus=FlatDetails::find($id);
        if($flatdetailstatus){
            $flatdetailstatus->status=$flatdetailstatus->status == 'inactive' ? 'active' : 'inactive';
            $flatdetailstatus->save();
            return response()->json(["message"=>'success','status'=>$flatdetailstatus->status == 'active' ? 1 :2]);
        
        }
        return response()->json(["message"=>'Failed  to change']);
    }

    // delete flatdetails

    public function deleteflatdetails(Request $request){
        $id=$request->input('id');
        $flatdetailsdelete=flatdetails::find($id);
        if (!$flatdetailsdelete) {
            session()->flash('messageType', 'fail');
            session()->flash('message', 'flatdetails not found.');
            return redirect()->route('admin.flatdetailslist');
        }
            $flatdetailsdelete->delete();
           
            session()->flash('messageType', 'success');
            session()->flash('message', ' Successfully flatdetails deleted!');
            return redirect()->route('admin.flatdetailslist');      

    }

    // edit flatdetails
    public function editflatdetails($id){
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $flatdetailsinfo=FlatDetails::find($id);
            $floor = DB::table('configoptions')
            ->leftJoin('configs', 'configoptions.configid', '=', 'configs.id')
                ->select('configoptions.id as id', 'configoptions.optionname as optionname')            
                ->where('configs.slug', '=', 'floor')
                ->get();
            $facing = DB::table('configoptions')
            ->leftJoin('configs', 'configoptions.configid', '=', 'configs.id')
                ->select('configoptions.id as id', 'configoptions.optionname as optionname')            
                ->where('configs.slug', '=', 'facing')
                ->get();
            // echo "<pre>";print_r($flatdetailsinfo);exit;
            return view('admin.master.flatdetails.editflatdetails',compact('flatdetailsinfo','floor','facing'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    // update flatdetails
    public function postupdateflatdetails(Request $request){
        $input=$request->all();
        // dd( $input);

        $result = $this->update($input);
        if($result ==1){
            session()->flash('messageType', 'success');
            session()->flash('message', 'flatdetails successfully updated');
        }
        return redirect()->route('admin.flatdetailslist');
    }

    // updating the values to the database

    public function update(array $input){

        $id=$input['flatdetailsid'];
        $data=FlatDetails::find($id);
        $data->flatno=$input['flatno'];
        $data->area=$input['area'];
        $data->floor = $input['floor'];
        $data->rooms = $input['room'];
        $data->facing = $input['facing'];
        $data->flatstatus = $input['flatstatus'];

        if ($data->isDirty()) {
            $data->updated_at = Carbon::now();
            $data->update();
            return 1;
        } else {
            return 0;
        }
    }

     // rendeering pdf 
     public function flatdetailspdf(){
        $allflatdetails = DB::table('flatdetails')
            ->join('configoptions as floors', 'flatdetails.floor', '=', 'floors.id')
            ->join('configoptions as facings', 'flatdetails.facing', '=', 'facings.id')
            ->select(
                'flatdetails.*',
                'floors.optionname as floor',
                'facings.optionname as facing',
                )
            ->where('flatdetails.deleted_at', '0')
            ->orderBy('flatdetails.id', 'desc')->get();
            $pdf = PDF::loadView('admin.master.flatdetails.exportflatdetails', compact('allflatdetails'));
            return $pdf->download('exportflatdetails' . time() . rand(99, 9999) .'.pdf');
    }

    // rendering excel
    public function flatdetailscsv(){
        $allflatdetails =DB::table('flatdetails')
            ->join('configoptions as floors', 'flatdetails.floor', '=', 'floors.id')
            ->join('configoptions as facings', 'flatdetails.facing', '=', 'facings.id')
            ->select(
                'flatdetails.*',
                'floors.optionname as floor',
                'facings.optionname as facing',
                )
            ->where('flatdetails.deleted_at', '0')
            ->orderBy('flatdetails.id', 'desc')->get();
        $export = new flatdetailsExport($allflatdetails);
        return Excel::download($export, 'flatdetailsExport' . time() . rand(99, 9999) . '.csv');
    }


}
