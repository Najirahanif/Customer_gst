<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\Faq;
use App\Exports\FaqExport;
use View;
use PDF;

class FaqController extends Controller {

    public function index() {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $faqlist = $this->getfaqlist();
            return view('admin.master.faq.index', compact('faqlist'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function getfaqlist() {
        return Faq::orderBy('id', 'desc')->where('deleted_at','0')->get();
    }

    public function addfaq() {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            return view('admin.master.faq.addfaq');
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }
        
    }

    public function postaddfaq(Request $request) {
        $input = $request->all();
        $result = $this->create($input);
        session()->flash('messageType', 'success');
        session()->flash('message', 'Faq successfully added');
        return redirect()->route('admin.faqlist');
    }

    public function create(array $input) {
        $faq = new Faq;
        $faq->question = ucwords(strtolower($input['question']));
        $faq->answer = ucwords(strtolower($input['answer']));
        $faq->created_at = Carbon::now();
        $faq->updated_at = Carbon::now();
        $faq->save();
        return 1;
    }

    public function faqstatuschange(Request $request)
    {
        $id = $request->input('id');
        $faq = Faq::find($id);
        if ($faq) {
            $faq->status = $faq->status == 'inactive' ? 'active' : 'inactive';
            $faq->save();
            return response()->json(["message"=>'success','status'=> $faq->status ==='active'? 1 : 2 ]);
        }
        return response()->json(["message"=>'Failed to change']);
    }

    public function deletefaq(Request $request) {
        $id = $request->input('id');
        $faq = Faq::find($id);
        if (!$faq) {
            session()->flash('messageType', 'fail');
            session()->flash('message', 'faq not found.');
            return redirect()->route('admin.faqlist');
        }
            $faq->deleted_at = '1';
            $faq->delete();
            session()->flash('messageType', 'success');
            session()->flash('message', 'Faq permanently deleted!');
            return redirect()->route('admin.faqlist');
    }

    public function editfaq($id) {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $faqInfo = Faq::find($id);
            return view('admin.master.faq.editfaq', compact('faqInfo'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function updatefaq(Request $request) {
        $input = $request->all();
        $result = $this->update($input);
        if($result == 1) {
            session()->flash('messageType', 'success');
            session()->flash('message', 'Faq successfully updated');
        }
        return redirect()->route('admin.faqlist');
    }

    public function update(array $input) {
        $faqs = new Faq;
        $id = $input['faqid'];
        $data = $faqs->find($id);
        $data->question = ucfirst($input['question']);
        $data->answer = ucfirst($input['answer']);
        if ($data->isDirty()) {
            $data->updated_at = Carbon::now();
            $data->save();
            return 1;
        } else {
            return 0;
        }
    }

    public function faqpdf() {
            $allfaq = Faq::where('deleted_at','0')->get();;
            $pdf = PDF::loadView('admin.master.faq.exportfaq', compact('allfaq'));
            return $pdf->download('exportfaq' . time() . rand(99, 9999) .'.pdf');
        
    }

    public function faqcsv() {
        $allfaq = DB::table('faqs')->where('deleted_at','0')->get();
        $export = new FaqExport($allfaq);
        return Excel::download($export, 'ExportFaq' . time() . rand(99, 9999) . '.csv');
    }

    public function checkQuestion(Request $request) {
        if ($request->has('question')) {
            $question = $request->input('question');
            $id = $request->input('id', null); 
            $query = DB::table('faqs')->where('question', $question);
            if ($id !== null) {
                $query->where('id', '!=', $id);
            }
            $count = $query->count();
            $response = [];
            if ($count > 0) {
                $response['message'] = "Question is already in the database.";
            } else {
                $response['message'] = "";
            }
            return response()->json($response);
        }
    }

}
