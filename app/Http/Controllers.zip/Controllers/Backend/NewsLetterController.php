<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\NewsLetter;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use PDF;
use Illuminate\Support\Facades\Session;
use App\Exports\NewsLetterExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\File;

class NewsLetterController extends Controller
{
    public function newsletterlist()
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $newsletterlist = $this->getnewsletterlist();
            return view('admin.master.newsletter.index', compact('newsletterlist'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function getnewsletterlist()
    {
        
        return NewsLetter::orderBy('id', 'desc')->where('deleted_at', '0')->get();
    }

    public function addnewsletter()
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            return view('admin.master.newsletter.addnewsletter');
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function postaddnewsletter(Request $request)
    {
        $input = $request->all();

        $filePath = resource_path('views/email/' . $input['slug'] . '.blade.php');
        if (!File::exists(dirname($filePath))) {
            File::makeDirectory(dirname($filePath), 0777, true, true);
        }
        $content = $request->input('description');
        File::put($filePath, $content);

        $this->create($input);

        session()->flash('messageType', 'success');
        session()->flash('message', 'News Letter successfully added');

        return redirect()->route('admin.newsletterlist');
    }

    public function create(array $input)
    {
        $newsletter = new NewsLetter();
        $newsletter->name = ucwords(strtolower($input['name']));
        $newsletter->slug = $input['slug'];
        $newsletter->subject = ucfirst($input['subject']);

        if (isset($input['discription'])) {
            $newsletter->discription = ucfirst($input['discription']);
        }

        $newsletter->created_at = Carbon::now();
        $newsletter->updated_at = Carbon::now();

        $fileContent = isset($input['discription']) ? $input['discription'] : '';
        $fileName = $input['slug'] . '.blade.php';

        $newsletter->save();

        $descriptionFile = fopen(resource_path('views/email/' . $fileName), 'a');
        if (!$descriptionFile) {
            // Handle the error, for example:
            // return redirect()->back()->with('error', 'Error creating description file');
        }
        fwrite($descriptionFile, $fileContent);
        fclose($descriptionFile);

        return 1;
    }


    public function newsletterstatuschange(Request $request)
    {
        $id = $request->input('id');
        $newsletter = NewsLetter::find($id);
        if ($newsletter) {
            $newsletter->status = $newsletter->status == 'inactive' ? 'active' : 'inactive';
            $newsletter->save();
            return response()->json(["message" => 'success', 'status' => $newsletter->status === 'active' ? 1 : 2]);
        }
        return response()->json(["message" => 'Failed to change']);
    }

    public function editnewsletter($id)
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $newsletterInfo = NewsLetter::find($id);
            return view('admin.master.newsletter.editnewsletter', compact('newsletterInfo'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }



    public function updatenewsletter(Request $request)
    {
        $input = $request->all();
        $result = $this->update($input);
        if ($result == 1) {
            session()->flash('messageType', 'success');
            session()->flash('message', 'News letter successfully updated');
        }
        return redirect()->route('admin.newsletterlist');
    }
    public function update(array $input)
    {
        $newsletter = NewsLetter::find($input['newsletterid']);
    
        if (!$newsletter) {
            // return redirect()->back()->with('error', 'Newsletter not found');
        }    
        $newsletter->name = ucwords(strtolower($input['name']));
        $newsletter->slug = $input['slug'];
        $newsletter->subject = ucfirst($input['subject']);
    
        if (isset($input['discription'])) {
            $newsletter->discription = ucfirst($input['discription']);
    
            $file = resource_path('views/email/' . $newsletter->slug . '.blade.php');
    
            // Write the new description to the file
            file_put_contents($file, $newsletter->discription );
    
            // Update the newsletter record
            $newsletter->updated_at = Carbon::now();
            $newsletter->save();
    
            return 1;
        }
    
        return 0;
    }
    
    
    public function deletenewsletter(Request $request)
    {
        $id = $request->input('id');
        $newsletter = NewsLetter::find($id);
        // echo "<pre>"; print_r($newsletter); echo "</pre>"; exit;
        if (!$newsletter) {
            session()->flash('messageType', 'fail');
            session()->flash('message', 'News letter not found.');
            return redirect()->route('admin.deletenewsletter');
        }

        $newsletter->delete();
        session()->flash('messageType', 'success');
        session()->flash('message', 'News letter deleted successuflly!');
        return redirect()->route('admin.newsletterlist');
    }

    public function checkName(Request $request)
    {
        if ($request->has('name')) {
            $name = $request->input('name');
            $id = $request->input('id', null);
            $query = DB::table('newsletters')->where('name', $name);
            if ($id !== null) {
                $query->where('id', '!=', $id);
            }
            $count = $query->count();
            $response = [];
            if ($count > 0) {
                $response['message'] = "Name is already in the database.";
            } else {
                $response['message'] = "";
            }
            return response()->json($response);
        }
    }

    public function newsletterpdf()
    {
        $allnewsletter = NewsLetter::where('deleted_at', '0')->get();
        $pdf = PDF::loadView('admin.master.newsletter.exportnewsletter', compact('allnewsletter'));
        return $pdf->download('exportnewsletter' . time() . rand(99, 9999) . '.pdf');
    }

    public function newslettercsv()
    {
        $allnewsletter = DB::table('newsletters')->where('deleted_at','0')->get();
        $export = new NewsLetterExport($allnewsletter);
        return Excel::download($export, 'ExportNewsLetter' . time() . rand(99, 9999) . '.csv');
    }
}
