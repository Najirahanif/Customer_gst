<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use View;
use App\Models\Settings; 
use App\Models\City;
use App\Models\Country;
use App\Models\State;
use App\Models\SiteSetting;
use App\Models\MailSettings;
use App\Models\SeoSetting;

class AdminController extends BaseController
{
    public function admindashboard()
    {
            return view('admin.dashboard.index');
    }

    public function index()
    {
        return view('admin.auth.login');
    }

    public function postadminlogin(Request $request)
    {
        $input = $request->all();
        $password = $input['password'];
        $result = $this->checklogin($input['username'], $password);
    
        if ($result == 1) {
            $this->updatelastlogin($input['username']);
            $adminuser = $this->getbyemail($input['username']);
            Session::put('adminname', $adminuser['name']);
            Session::put('logintype', 'admin');
            return Redirect::route('admin.dashboard');
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Invalid username/password');
            return Redirect::route('admin.login');
        }
    }
    

    public function updatelastlogin($email)
    {
        $admin = new Settings;
        $id = $admin->where('email', '=', $email)->value('id');
        $data = $admin->find($id);
        $data->lastlogindate = Carbon::now();
        $data->save();
        return $id;
    }

    public function getbyemail($email)
    {
        $admin = new Settings;
        return $admin->where('email', '=', $email)->first();
    }

    public function checklogin($email, $password)
    {
        $admin = new Settings;
        $hashed = $admin->where('email', '=', $email)->value('password');
        $result = Hash::check($password, $hashed);
        return $result;
    }

    public function adminlogout()
    {
        Session::forget('logintype');
        Session::forget('adminname');
        return Redirect::route('admin.login');
    }
    public function adminsettingsindex(){
        $admininfo= Settings::find(1);
        $sitesettinginfo= SiteSetting::find(1);
        $seosettinginfo= SeoSetting::find(1);
        $mailsettinginfo= MailSettings::find(1);
        $country=Country::where('status','=','active')->get();
        $state=State::where('status','=','active')->get();
        $city=City::where('status','=','active')->get();
        $mobilenumber = DB::table('configoptions')
        ->leftJoin('configs', 'configoptions.configid', '=', 'configs.id')
            ->select('configoptions.id as id', 'configoptions.optionname as optionname')            
            ->where('configs.slug', '=', 'admin-mobile-number')
            ->get();
        $editmobilenumber = explode(',', $admininfo->mobilenumber);
        // dd($sitesettinginfo);

        return view('admin.settings.index',compact('country','state','city','mobilenumber','editmobilenumber','admininfo','sitesettinginfo','seosettinginfo','mailsettinginfo'));
    }

    public function postadminprofile(Request $request){
        $input = $request->all();
        // dd($input);
        $id = $request->input('id');
        $destinationPath = 'uploads/images/settings/adminprofile';
    
        if ($request->hasFile('image')) {
            $logoimg = $request->file('image');
            $logoext = $logoimg->getClientOriginalExtension();
            $filename = rand(100000, 999999);
            $file = $filename . '.' . $logoext;
            $logoimg->move($destinationPath, $file);
            $settinglink = $destinationPath . '/' . $file;
            $input['image'] = $settinglink;
        } else {
            unset($input['image']);
        }
    
        // Process mobilenumber if present
        $mobilenumber = isset($input['mobilenumber']) ? $input['mobilenumber'] : null;
        $serializedmobilenumber = is_array($mobilenumber) ? implode(',', $mobilenumber) : '';
        
        // Find and update the admin settings
        $updateadmin = Settings::find($id);
        $updateadmin->name = ucwords(strtolower($input['name']));
        $updateadmin->email = $input['email'];
        $updateadmin->about = ucwords(strtolower($input['about']));
        $updateadmin->country = $input['country'];
        $updateadmin->location = $input['location'];
        $updateadmin->phonecode = $input['phonecode'];
        $updateadmin->pincode = $input['pincode'];
        $updateadmin->state = $input['state'];
        $updateadmin->city = $input['city'];
        $updateadmin->officenumber = $input['officenumber'];
        $updateadmin->flataddress = $input['flataddress'];
        $updateadmin->mobilenumber = $serializedmobilenumber;
        $updateadmin->address = $input['address'];
        // Check if 'image' is set in input before assigning
        if (isset($input['image'])) {
            $updateadmin->image = $input['image'];
        }
        $updateadmin->plotno = $input['plotno'];
        $updateadmin->updated_at = now(); // Carbon::now() for earlier Laravel versions
        $updateadmin->update();
            
        // Flash success message and redirect
        session()->flash('messageType', 'success');
        session()->flash('message', 'Admin Profile successfully updated');
            
        return redirect()->route('admin.adminsettings')->with('activeTab', 'pills-Admin');
    }
    

    public function postpasswordchange(Request $request ){
        $input=$request->all();
        // dd($input);
        $updatepassword= Settings::find(1);
        $updatepassword->password=hash::make($input['cnfrmpass']);
        $updatepassword->updated_at = Carbon::now();
        $updatepassword->update();
        // return redirect()->route('admin.adminsettings');
        session()->flash('messageType', 'success');
        session()->flash('message', 'Password successfully updated');
        return redirect()->route('admin.adminsettings')->with('activeTab', 'pills-Password');
    }
    public function getPhoneCode(Request $request) {
        $countryID = $request->input('countryID');
        $country = Country::find($countryID);
        if ($country) {
            return response()->json(['phonecode' => $country->code]);
        } else {
            return response()->json(['phonecode' => '']); 
        }
    }
}
