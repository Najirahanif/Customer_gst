<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\DB;
use App\Models\Country;
use App\Models\State;
use Carbon\Carbon;
use App\Exports\CountryExport;
use View;
use PDF;

class CountryController extends Controller
{

    public function index() {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $countrylist = $this->getcountrylist();
            return view('admin.master.country.index', compact('countrylist'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function getcountrylist() {
        return Country::orderBy('id', 'desc')->where('deleted_at','0')->get();
    }

    public function addcountry()
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            return view('admin.master.country.addcountry');
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }



    public function postaddcountry(Request $request)
    {
        $input = $request->all();
        $result = $this->create($input);
        session()->flash('messageType', 'success');
        session()->flash('message', 'Country successfully added');
        return redirect()->route('admin.countrylist');
    }

    public function create(array $input)
    {
        $country = new Country;
        $country->name = ucwords(strtolower($input['name']));
        $country->iso = $input['iso'];
        $country->code = explode(' ', $input['code'])[0];
        $country->created_at = Carbon::now();
        $country->updated_at = Carbon::now();
        $country->save();
        return 1;
    }
    public function softdeletecountry(Request $request)
    {
        $id = $request->input('id');
        $country = Country::find($id);
        $state = State::where('country', $id)->exists();
        if ($state) {
            session()->flash('messageType', 'error');
            session()->flash('message', 'Oops!, This Country is  assosiated with State');
            return redirect()->route('admin.countrylist');
        } else {
            if (!$country) {
                session()->flash('messageType', 'error');
                session()->flash('message', 'Country not found.');
                return redirect()->route('admin.countrylist');
            }
            $country->deleted_at = '1';
            $country->save();
            session()->flash('messageType', 'success');
            session()->flash('message', 'Country temporarily deleted!');
            return redirect()->route('admin.countrylist');
        }
    }

        public function countrychangestatus(Request $request)
        {
            $id = $request->input('id');
            $country = Country::find($id);
            // if ($country) {
            //     $country->status = $country->status == 'inactive' ? 'active' : 'inactive';
            //     $country->save();
            //     return response()->json(["message" => 'success', 'status' => $country->status === 'active' ? 1 : 2]);
            // }
            $countrystatus=$country->status;
            $associatedstates=State::where('country',$id)->exists();

            if($associatedstates && $countrystatus == 'active'){
                return response()->json(["message"=>'Unable to change country field active in state']);

            }
            else if($country){
                $country->status=$country->status=='inactive' ? 'active' : 'inactive';
                $country->save();
                return response()->json(["message"=>'success','status'=>$country->status=='active'? 1:2]);

            }
            return response()->json(["message" => 'Failed to change']);
        }


        public function editcountry($id){
            if (Session::has('adminname') && Session::get('logintype') === 'admin') {
                $country = Country::find($id);
                return view('admin.master.country.editcountry', compact('country'));
            } else {
                Session::flash('messageType', 'error');
                Session::flash('message', 'Login to your Account');
                return redirect()->route('admin.login');
            }

        }

        public function postupdatecountry(Request $request) {
            $input = $request->all();
            $result = $this->update($input);
            if($result == 1) {
                session()->flash('messageType', 'success');
                session()->flash('message', 'Country Details successfully updated');
            }
            return redirect()->route('admin.countrylist');
        }
    
        public function update(array $input) {
            $id = $input['countryid'];
            $country = new Country;
            $data = $country->find($id);
            $data->name = ucwords(strtolower($input['name']));
            $data->iso = $input['iso'];
            $data->code = $input['code'];
            if ($data->isDirty()) {
                $data->updated_at = Carbon::now();
                $data->save();
                return 1;
            } else {
                return 0;
            }
        }
        public function countrypdf() {
            $allcountry = Country::where('deleted_at','0')->get();
            $pdf = PDF::loadView('admin.master.country.exportcountry', compact('allcountry'));
            return $pdf->download('exportcountry' . time() . rand(99, 9999) .'.pdf');
    }

    public function exportcountrycsv() {
        $allcountry = DB::table('countries')->where('deleted_at','0')->get();
        $export = new CountryExport($allcountry);
        return Excel::download($export, 'ExportCountry' . time() . rand(99, 9999) . '.csv');
    }

    public function countrytrashlist() {
        $countrylist = Country::where('deleted_at', '1')->get();
        return view('admin.trash.master.country.index', compact('countrylist'));
    }

    public function restorecountry()
    {
        $id = request('id');
        $country = Country::find($id);
        if ($country) {
            $country->deleted_at = '0';
            $country->save();
            session()->flash('messageType', 'success');
            session()->flash('message', 'Country restore successfully!');
            return redirect()->route('admin.countrylist');
        }
    }

    }