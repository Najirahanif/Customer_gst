<?php

namespace App\Http\Controllers\Backend;
use Illuminate\Support\Str;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use App\Models\Config;
use App\Models\Configoption;
use Illuminate\Http\Request;
use PDF;

class ConfigController extends Controller
{
    public function index()
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $config = Config::orderBy('id', 'desc')->get();
            return view('admin.master.config.index', compact('config'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function addconfig()
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            return view('admin.master.config.addconfig');
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }
      
    }

    public function editconfig(Request $request)
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $id = $request->input('id');
            $configInfo = Config::find($id);
            $allconfigoptionInfo = Configoption::where('configid', $id)->get();
            return view('admin.master.config.editconfig', compact('configInfo', 'allconfigoptionInfo'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function deleteconfig(Request $request)
    {
        $id = $request->input('id');
        $this->deleteconfigbyid($id);
        Session::flash('messageType', 'success');
        Session::flash('message', 'Config successfully deleted!');
        return redirect()->route('config.index');
    }

    public function deleteconfigbyid($id)
    {
        $config = Config::find($id);
        if ($config) {
            $allconfigoptionInfo = Configoption::where('configid', $id)->get();
            foreach ($allconfigoptionInfo as $configOption) {
                $configOption->delete();
            }
            $config->delete();
        }
    }
    

    public function postconfig(Request $request)
    {
        $name = ucfirst($request->input('name'));
        $slug = Str::slug($name);

        $isconfignameAlreadyExist = Config::where('name', $name)->first();

        if ($isconfignameAlreadyExist) {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Config already exists!');
            return redirect()->route('config.index');
        } else {
            $config = new Config();
            $config->name = $name;
            $config->slug = $slug;
            $config->status = 'Active';
            $config->save();
            Session::flash('messageType', 'success');
            Session::flash('message', 'Config Successfully Added!');
            return redirect()->route('config.index');
        }
    }

    public function updateconfig(Request $request)
    {
        $id = $request->input('id');
        $configInfo = Config::find($id);
        $addMoreInputFields = $request->input('addMoreInputFields');

        $existingConfigOptions = Configoption::where('configid', $configInfo->id)->get();
        $processedOptionNames = [];

        foreach ($addMoreInputFields as $key => $value) {
            $optionName = strval($value['subject']);

            if (!empty($optionName) && !in_array($optionName, $processedOptionNames)) {
                $existingConfigOption = $existingConfigOptions
                    ->where('optionname', $optionName)
                    ->first();

                if ($existingConfigOption) {
                    $existingConfigOption->update([
                        'optionname' => $optionName
                    ]);
                } else {
                    $configoption = new Configoption();
                    $configoption->configid = $configInfo->id;
                    $configoption->optionname = $optionName;
                    $configoption->save();
                }
                $processedOptionNames[] = $optionName;
            }
        }

        $deletedOptionNames = $existingConfigOptions
            ->whereNotIn('optionname', $processedOptionNames)
            ->pluck('optionname');

        Configoption::where('configid', $configInfo->id)
            ->whereIn('optionname', $deletedOptionNames)
            ->delete();

        Session::flash('messageType', 'success');
        Session::flash('message', 'Config Successfully Updated!');
        return redirect()->route('config.index');
    }

    // public function export()
    // {
    //     $config = Config::all();

    //     foreach ($config as $configItem) {
    //         $configItem->options = Configoption::where('configid', $configItem->id)->pluck('optionname')->toArray();
    //     }
    
    //     $pdf = PDF::loadView('admin.master.config.export', compact('config'));
    //     return $pdf->download('exportconfig.pdf');
    // }
    public function configstatuschange(Request $request)
    {
        $id = $request->input('id');
        $brand = Config::find($id);
        if ($brand) {
            $brand->status = $brand->status == 'inactive' ? 'active' : 'inactive';
            $brand->save();
            return response()->json(["message"=>'success','status'=> $brand->status ==='active'? 1 : 2 ]);
        }
        return response()->json(["message"=>'Failed to change']);
    }

    public function checkName(Request $request) {
        if ($request->has('name')) {
            $name = $request->input('name');
            $id = $request->input('id', null); 
            $query = DB::table('configs')->where('name', $name);
            if ($id !== null) {
                $query->where('id', '!=', $id);
            }
            $count = $query->count();
            $response = [];
            if ($count > 0) {
                $response['message'] = "Name is already in the database.";
            } else {
                $response['message'] = "";
            }
            return response()->json($response);
        }
    }
}
 