<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\SiteSetting;
use Illuminate\Http\Request;

class SiteSettingsController extends Controller
{
    public function postsitesetting(Request $request){
        $input = $request->all();
        
        // Find the site setting with ID 1
        $updatecite = SiteSetting::find(1);
    
        // Check if the site setting was found
        if ($updatecite) {
            $destinationPath = 'uploads/images/settings/sitesetting';
    
            // Handle logo file upload
            if ($request->hasFile('logo')) {
                $logoimg = $request->file('logo');
                $logoext = $logoimg->getClientOriginalExtension();
                $filename = rand(100000, 999999);
                $file = $filename . '.' . $logoext;
                $logoimg->move($destinationPath, $file);
                $settinglink = $destinationPath . '/' . $file;
                $input['logo'] = $settinglink;  
            }
    
            // Handle favicon file upload
            if ($request->hasFile('favi')) {
                $logoimg = $request->file('favi');
                $logoext = $logoimg->getClientOriginalExtension();
                $filename = rand(100000, 999999);
                $file = $filename . '.' . $logoext;
                $logoimg->move($destinationPath, $file);
                $settinglink = $destinationPath . '/' . $file;
                $input['favi'] = $settinglink;
            }
    
            // Update the site setting with the input data
            $updatecite->logo = $input['logo'] ?? $updatecite->logo;
            $updatecite->favi = $input['favi'] ?? $updatecite->favi;
            $updatecite->name = ucwords(strtolower($input['name'])) ?? $updatecite->name;
            $updatecite->update();
    
            // Flash success message and redirect
            session()->flash('messageType', 'success');
            session()->flash('message', 'Site settings successfully updated');
            return redirect()->route('admin.adminsettings')->with('activeTab', 'pills-Cite');
        } else {
            // Handle case where site setting was not found
            session()->flash('messageType', 'error');
            session()->flash('message', 'Failed to update site settings. Site setting not found.');
            return redirect()->route('admin.adminsettings')->with('activeTab', 'pills-Cite');
        }
    }
    
}
