<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use App\Models\Gallery;
use View;
use PDF;

class GalleryController extends Controller {

    public function index() {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $gallerylist = $this->getgallerylist();
            return view('admin.gallery.index', compact('gallerylist'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function getgallerylist() {
        return Gallery::orderBy('id', 'desc')->where('deleted_at','0')->get();
    }

    public function addgallery() {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $icons = DB::table('configoptions')
            ->leftJoin('configs', 'configoptions.configid', '=', 'configs.id')
                ->select('configoptions.id as id', 'configoptions.optionname as optionname')            
                ->where('configs.slug', '=', 'icons')
                ->get();
            return view('admin.gallery.addgallery',compact('icons'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function postaddgallery(Request $request) {
        $input = $request->all();
        $imagePath = 'uploads/images/gallerys';
        if ($request->hasFile('image')) {
            $logoimg = $request->file('image');
            $logoext = $logoimg->getClientOriginalExtension();
            $filename = rand(100000, 999999);
            $file = $filename . '.' . $logoext;
            $logoimg->move($imagePath, $file);
            $settinglink = $imagePath . '/' . $file;
            $input['image'] = $settinglink;
        }
        $result = $this->create($input);
        // dd($input);
        session()->flash('messageType', 'success');
        session()->flash('message', 'gallery successfully added');
        return redirect()->route('admin.gallerylist');
    }

    public function create(array $input) {
        $gallery = new Gallery;
        $gallery->image = $input['image'];
        $gallery->created_at = Carbon::now();
        $gallery->updated_at = Carbon::now();
        $gallery->save();
        return 1;
    }

    public function gallerystatuschange(Request $request)
    {
        $id = $request->input('id');
        $gallery = Gallery::find($id);
        if ($gallery) {
            $gallery->status = $gallery->status == 'inactive' ? 'active' : 'inactive';
            $gallery->save();
            return response()->json(["message"=>'success','status'=> $gallery->status ==='active'? 1 : 2 ]);
        }
        return response()->json(["message"=>'Failed to change']);
    }

    public function deletegallery(Request $request) {
        $id = $request->input('id');
        $gallery = Gallery::find($id);
        if (!$gallery) {
            session()->flash('messageType', 'fail');
            session()->flash('message', 'gallery not found.');
            return redirect()->route('admin.gallerylist');
        }
            $gallery->delete();
            session()->flash('messageType', 'success');
            session()->flash('message', 'gallery successfully deleted!');
            return redirect()->route('admin.gallerylist');
    }

    public function editgallery($id) {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $galleryInfo = Gallery::find($id);
            $icons = DB::table('configoptions')
            ->select('configoptions.id', 'configoptions.optionname')
            ->leftJoin('configs', 'configoptions.configid', '=', 'configs.id')
            ->where('configs.slug', '=', 'icons')
            ->get();
            return view('admin.gallery.editgallery', compact('galleryInfo','icons'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function updategallery(Request $request) {
        $input = $request->all();
        $destinationPath = 'uploads/images/gallerys';
        if ($request->file('image')) {
            $logoimg = $request->file('image');
            $logoext = $logoimg->getClientOriginalExtension();
                $filename = rand(100000, 999999);
                $file = $filename . '.' . $logoext;
                $logoimg->move($destinationPath, $file);
                $settinglink = $destinationPath . '/' . $file;
                $input['image'] = $settinglink;
        }
        $result = $this->update($input);
        if($result == 1) {
            session()->flash('messageType', 'success');
            session()->flash('message', 'gallery successfully updated');
        }
        return redirect()->route('admin.gallerylist');
    }

    public function update(array $input) {
        $gallerys = new Gallery;
        $id = $input['galleryid'];
        $data = $gallerys->find($id);
        if (isset($input['image']) && !empty($input['image'])) {
            if (file_exists($data->image)) {
                unlink($data->image);
            }
            $data->image = $input['image'];
        }
        if ($data->isDirty()) {
            $data->updated_at = Carbon::now();  
            $data->save();
            return 1;
        } else {
            return 0;
        }
    }

}
