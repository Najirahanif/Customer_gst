<?php

namespace App\Http\Controllers\backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\Slider;
use App\Exports\SliderExport;
use View;
use PDF;

class SliderController extends Controller
{
    public function index() {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $slider = $this->getsliderlist();
            return view('admin.master.slider.index', compact('slider'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function getsliderlist() {
        return Slider::orderBy('id', 'desc')->where('deleted_at','0')->get();
    }

    public function addslider() {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            return view('admin.master.slider.addslider');
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function postaddslider(Request $request) {
        $input = $request->all();
        $imagePath = 'uploads/images/slider';
        if ($request->hasFile('image')) {
                    $logoimg = $request->file('image');
                    $logoext = $logoimg->getClientOriginalExtension();
                    $filename = rand(100000, 999999);
                    $file = $filename . '.' . $logoext;
                    $logoimg->move($imagePath, $file);
                    $settinglink = $imagePath . '/' . $file;
                    $input['image'] = $settinglink;
                }
        $result = $this->create($input);
        session()->flash('messageType', 'success');
        session()->flash('message', 'Slider successfully added');
        return redirect()->route('admin.sliderlist');
    }

    public function create(array $input) {
        $slider = new Slider;
        $slider->title = ucwords(strtolower($input['title']));
        $slider->description = ucwords(strtolower($input['description']));
        $slider->image = $input['image'];
        $slider->bannertype =$input['bannertype'];
        $slider->created_at = Carbon::now();
        $slider->updated_at = Carbon::now();
        $slider->save();
        return 1;
    }

    public function sliderchangestatus(Request $request)
    {
        $id = $request->input('id');
        $slider = Slider::find($id);
        if ($slider) {
            $slider->status = $slider->status == 'inactive' ? 'active' : 'inactive';
            $slider->save();
            return response()->json(["message"=>'success','status'=> $slider->status ==='active'? 1 : 2 ]);
        }
        return response()->json(["message"=>'Failed to change']);
    }


    public function editslider($id) {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $sliderinfo = Slider::find($id);
            return view('admin.master.slider.editslider', compact('sliderinfo'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function updateslider(Request $request) {
        $input = $request->all();
        $destinationPath = 'uploads/images/slider';
        if ($request->file('image')) {
            $logoimg = $request->file('image');
            $logoext = $logoimg->getClientOriginalExtension();
                $filename = rand(100000, 999999);
                $file = $filename . '.' . $logoext;
                $logoimg->move($destinationPath, $file);
                $settinglink = $destinationPath . '/' . $file;
                $input['image'] = $settinglink;
        }
        $result = $this->update($input);
        if($result == 1) {
            session()->flash('messageType', 'success');
            session()->flash('message', 'Slider successfully updated');
        }
        return redirect()->route('admin.sliderlist');
    }

    public function update(array $input) {
        $slider = new Slider; 
        $id = $input['sliderid'];
        $data = $slider->find($id); 
        $data->title = ucfirst($input['title']);
        $data->description = ucfirst($input['description']);
        $data->bannertype =$input['bannertype'];
        $data->button =ucwords($input['button']);
        if (isset($input['image']) && !empty($input['image'])) {
            if (file_exists($data->image)) {
                unlink($data->image);
            }
            $data->image = $input['image'];
        }
        if ($data->isDirty()) {
            $data->updated_at = Carbon::now();
            $data->save();
            return 1;
        } else {
            return 0;
        }
    }    

    public function deleteslider(Request $request){
        $id = $request->input('id');
        try {
            $slider = Slider::find($id);
            if (!$slider) {
                return response()->json(["message" => 'Student not found'], 404);
            }
            $slider->delete();
            session()->flash('messageType', 'success');
            session()->flash('message', 'Slider deleted!');
            return redirect('/slider');

    
        } catch (\Throwable $th) {
            return redirect('/slider')->with("message", "Failed to delete list");
    
        }
    }


    public function sliderpdf() {
        $allslider = Slider::where('deleted_at','0')->get();;
        $pdf = PDF::loadView('admin.master.slider.exportslider', compact('allslider'));
        return $pdf->download('exportslider' . time() . rand(99, 9999) .'.pdf');
    
    }

    public function exportslidercsv() {
        $allbrand = DB::table('sliders')->where('deleted_at','0')->get();
        $export = new SliderExport($allbrand);
        return Excel::download($export, 'exportslider' . time() . rand(99, 9999) . '.csv');
    }


    public function checkName(Request $request) {
        if ($request->has('name')) {
            $name = $request->input('name');
            $id = $request->input('id', null); 
            $query = DB::table('sliders')->where('name', $name);
            if ($id !== null) {
                $query->where('id', '!=', $id);
            }
            $count = $query->count();
            $response = [];
            if ($count > 0) {
                $response['message'] = "Name is already in the database.";
            } else {
                $response['message'] = "";
            }
            return response()->json($response);
        }
    }



}










