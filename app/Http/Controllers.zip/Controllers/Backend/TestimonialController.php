<?php

namespace App\Http\Controllers\Backend;

use App\Exports\TestimonialExport;
use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Carbon\Carbon;
use App\Models\Testimonial;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Maatwebsite\Excel\Facades\Excel;
use View;
use PDF;

class TestimonialController extends Controller
{

    public function index()
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $alldata= $this->gettestimoniallist();        
            return view('admin.master.testimonial.index',compact('alldata'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }
    public function gettestimoniallist(){
        return Testimonial::orderBy('id','desc')->where('deleted_at','0')->get();
    }

    public function testimonialadd()
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            return view('admin.master.testimonial.addtestimonial');
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

     public function checkName(Request $request) {
        if ($request->has('name')) {
            $name = $request->input('name');
            $id = $request->input('id', null); 
            $query = DB::table('testimonials')->where('name', $name);
            if ($id !== null) {
                $query->where('id', '!=', $id);
            }
            $count = $query->count();
            $response = [];
            if ($count > 0) {
                $response['message'] = "Name is already in the database.";
            } else {
                $response['message'] = "";
            }
            return response()->json($response);
        }
    }

    public function posttestimonial(Request $request){
        $input=$request->all();
        // echo "<pre>";print_r($input);exit;

        // image path
        $imagePath = 'uploads/images/testimonials';
        if ($request->hasFile('image')) {
            $logoimg = $request->file('image');
            $logoext = $logoimg->getClientOriginalExtension();
            $filename = rand(100000, 999999);
            $file = $filename . '.' . $logoext;
            $logoimg->move($imagePath, $file);
            $settinglink = $imagePath . '/' . $file;
            $input['image'] = $settinglink;
        }
        $result = $this->create($input);
        session()->flash('messageType','success');
        session()->flash('message', 'testimonial successfully added');
        return redirect()->route('admin.testimonial.list');

    }

    public function create( array $input)
    {
        $testimonial=new Testimonial;
        $testimonial->name = ucwords(strtolower($input['name']));
        $testimonial->description = ucwords(strtolower($input['description']));
        $testimonial->image = $input['image'];
        $testimonial->created_at = Carbon::now();
        $testimonial->updated_at = Carbon::now();
        $testimonial->save();
        return 1;

    }

    public function statuschangetestimonial(Request $request){
        $id=$request->input('id');
        $testimonial=Testimonial::find($id);
        $testimonialstatus=$testimonial->status;
        $testimonial->status=$testimonial->status == 'inactive' ? 'active' : 'inactive';
        $testimonial->save();
        return response()->json(["message"=>'success','status'=>$testimonial->status == 'active' ? 1 :2]);        
    }

    // delete temperorily

    public function deletetestimonial( Request $request){
       
        $id=$request->input('id');
        $testimonial=Testimonial::find($id);

            $testimonial->deleted_at = '1';
            $testimonial->save();
            session()->flash('messageType', 'success');
            session()->flash('message', 'testimonial temporarily deleted!');
            return redirect()->route('admin.testimonial.list');  
        
               
    }

    // listing the deleted items in trash
    
    public function trashlisttestimonial(){

        $testimoniallist = Testimonial::where('deleted_at','1')->get();

        return view('admin.trash.testimonial.index', compact('testimoniallist'));
    }
    // restore the deleted 

    public function testimonialrestore(Request $request){
        $id = request('id');
        $testimonial = Testimonial::find($id);
        // dd($testimonial);
        if ($testimonial) {
            $testimonial->deleted_at = '0';
            $testimonial->save();
            session()->flash('messageType', 'success');
            session()->flash('message', 'testimonial restored successfully!');
            return redirect()->route('admin.testimonial.list');
        }
    }


    // edit function
    public function edittestimonial($id)
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $testimonialinfo=Testimonial::find($id);
            return view('admin.master.testimonial.edittestimonial',compact('testimonialinfo'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function postupdatetestimonial(Request $request)
    {
        $input = $request->all();
        $destinationPath = 'uploads/images/testimonials';

        if ($request->hasFile('image')) {
            $logoimg = $request->file('image');
            $logoext = $logoimg->getClientOriginalExtension();
            $filename = rand(100000, 999999);
            $file = $filename . '.' . $logoext;
            $logoimg->move($destinationPath, $file);
            $settinglink = $destinationPath . '/' . $file;
            $input['image'] = $settinglink;
        }

        $result = $this->update($input);

        if ($result == 1) {
            session()->flash('messageType', 'success');
            session()->flash('message', 'testimonial successfully updated');
        }

        return redirect()->route('admin.testimonial.list');
    }

    public function update(array $input)
{
    $id = $input['testimonialid'];
    $data = Testimonial::find($id);

    if (!$data) {
        // Handle case where testimonial with given ID is not found
        return 0;
    }
    $data->name = ucfirst(strtolower($input['name']));
    $data->description = ucwords($input['description']);

    if (array_key_exists('image', $input) && $input['image']) {
        if (file_exists($data->image)) {
            unlink($data->image);
        }
        $data->image = $input['image'];
    }

    if ($data->isDirty()) {
        $data->updated_at = Carbon::now();
        $data->save();
        return 1;
    } else {
        return 0;
    }
}


    // rendeering pdf 
    public function testimonialpdf(){
        $alltestimonial = Testimonial::where('deleted_at','0')->get();
            $pdf = PDF::loadView('admin.master.testimonial.exporttestimonial', compact('alltestimonial'));
            return $pdf->download('export-testimonial' . time() . rand(99, 9999) .'.pdf');
    }

    // rendering excel
    public function testimonialcsv(){
        $alltestimonial =Testimonial::where('deleted_at','0')->get();
        $export = new TestimonialExport($alltestimonial);
        return Excel::download($export, 'Exporttestimonial' . time() . rand(99, 9999) . '.csv');
    }
}

