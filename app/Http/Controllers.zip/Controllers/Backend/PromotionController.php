<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\Promotion;
use App\Exports\PromotionExport;
use View;
use PDF;

class PromotionController extends Controller {

    public function index() {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $promotionlist = $this->getpromotionlist();
            return view('admin.promotion.index', compact('promotionlist'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function getpromotionlist() {
        return Promotion::orderBy('id', 'desc')->where('deleted_at','0')->get();
    }

    public function addpromotion() {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $icons = DB::table('configoptions')
            ->leftJoin('configs', 'configoptions.configid', '=', 'configs.id')
                ->select('configoptions.id as id', 'configoptions.optionname as optionname')            
                ->where('configs.slug', '=', 'icons')
                ->get();
            return view('admin.promotion.addpromotion',compact('icons'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function postaddpromotion(Request $request) {
        $input = $request->all();
        $imagePath = 'uploads/images/promotions';
        if ($request->hasFile('image')) {
            $logoimg = $request->file('image');
            $logoext = $logoimg->getClientOriginalExtension();
            $filename = rand(100000, 999999);
            $file = $filename . '.' . $logoext;
            $logoimg->move($imagePath, $file);
            $settinglink = $imagePath . '/' . $file;
            $input['image'] = $settinglink;
        }
        $result = $this->create($input);
        // dd($input);
        session()->flash('messageType', 'success');
        session()->flash('message', 'promotion successfully added');
        return redirect()->route('admin.promotionlist');
    }

    public function create(array $input) {
        $promotion = new Promotion;
        $promotion->icon = $input['icon'];
        $promotion->name = strtoupper($input['name']);
        $promotion->image = $input['image'];
        $promotion->created_at = Carbon::now();
        $promotion->updated_at = Carbon::now();
        $promotion->save();
        return 1;
    }

    public function promotionstatuschange(Request $request)
    {
        $id = $request->input('id');
        $promotion = Promotion::find($id);
        if ($promotion) {
            $promotion->status = $promotion->status == 'inactive' ? 'active' : 'inactive';
            $promotion->save();
            return response()->json(["message"=>'success','status'=> $promotion->status ==='active'? 1 : 2 ]);
        }
        return response()->json(["message"=>'Failed to change']);
    }

    public function softdeletepromotion(Request $request) {
        $id = $request->input('id');
        $promotion = Promotion::find($id);
        if (!$promotion) {
            session()->flash('messageType', 'fail');
            session()->flash('message', 'promotion not found.');
            return redirect()->route('admin.promotionlist');
        }
            $promotion->deleted_at = '1';
            $promotion->save();
            session()->flash('messageType', 'success');
            session()->flash('message', 'promotion temporarily deleted!');
            return redirect()->route('admin.promotionlist');
    }

    public function editpromotion($id) {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $promotionInfo = Promotion::find($id);
            $icons = DB::table('configoptions')
            ->select('configoptions.id', 'configoptions.optionname')
            ->leftJoin('configs', 'configoptions.configid', '=', 'configs.id')
            ->where('configs.slug', '=', 'icons')
            ->get();
            return view('admin.promotion.editpromotion', compact('promotionInfo','icons'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function updatepromotion(Request $request) {
        $input = $request->all();
        $destinationPath = 'uploads/images/promotions';
        if ($request->file('image')) {
            $logoimg = $request->file('image');
            $logoext = $logoimg->getClientOriginalExtension();
                $filename = rand(100000, 999999);
                $file = $filename . '.' . $logoext;
                $logoimg->move($destinationPath, $file);
                $settinglink = $destinationPath . '/' . $file;
                $input['image'] = $settinglink;
        }
        $result = $this->update($input);
        if($result == 1) {
            session()->flash('messageType', 'success');
            session()->flash('message', 'promotion successfully updated');
        }
        return redirect()->route('admin.promotionlist');
    }

    public function update(array $input) {
        $promotions = new Promotion;
        $id = $input['promotionid'];
        $data = $promotions->find($id);
        $data->icon = $input['icon'];
        $data->name = strtoupper($input['name']);
        if (isset($input['image']) && !empty($input['image'])) {
            if (file_exists($data->image)) {
                unlink($data->image);
            }
            $data->image = $input['image'];
        }
        if ($data->isDirty()) {
            $data->updated_at = Carbon::now();  
            $data->save();
            return 1;
        } else {
            return 0;
        }
    }

    public function promotionpdf() {
            $allpromotion = Promotion::where('deleted_at','0')->get();
            $pdf = PDF::loadView('admin.promotion.exportpromotion', compact('allpromotion'));
            return $pdf->download('exportpromotion' . time() . rand(99, 9999) .'.pdf');
    }

    public function promotioncsv() {
        $allpromotion = DB::table('promotions')->where('deleted_at','0')->get();
        $export = new PromotionExport($allpromotion);
        return Excel::download($export, 'ExportPromotion' . time() . rand(99, 9999) . '.csv');
    }
    
    public function promotiontrashlist() {
            $promotionlist = Promotion::where('deleted_at', '1')->get();
            return view('admin.trash.promotion.index', compact('promotionlist'));
    }

    public function restore()
    {
        $id = request('id');
        $promotion = Promotion::find($id);
        if ($promotion) {
            $promotion->deleted_at = '0';
            $promotion->save();
            session()->flash('messageType', 'success');
            session()->flash('message', 'promotion restore successfully!');
            return redirect()->route('admin.promotionlist');
        }
    }

    public function checkName(Request $request) {
        if ($request->has('name')) {
            $name = $request->input('name');
            $id = $request->input('id', null); 
            $query = DB::table('promotions')->where('name', $name);
            if ($id !== null) {
                $query->where('id', '!=', $id);
            }
            $count = $query->count();
            $response = [];
            if ($count > 0) {
                $response['message'] = "Name is already in the database.";
            } else {
                $response['message'] = "";
            }
            return response()->json($response);
        }
    }

}
