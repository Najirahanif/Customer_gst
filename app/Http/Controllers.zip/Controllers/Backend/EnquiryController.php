<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\Contact;
use App\Exports\EnquiryExport;
use View;
use PDF;

class EnquiryController extends Controller {


    public function enquirylistpage() {
        $enquiry=Contact::all();
    return view('admin.enquiry.index',compact('enquiry'));
       
}
public function enquirypdf()
{
    $enquiry=Contact::all();
    $pdf = PDF::loadView('admin.enquiry.exportenquiry',compact('enquiry'));
    return $pdf->download('ExportEnquiries'. time() . rand(99, 9999) .'.pdf');
   
}

public function enquirycsv()
{
    $data = Contact::select(['id', 'name', 'email', 'contact_number','message'])->get()->toArray();

    $export = new EnquiryExport($data); // Pass the array directly to the constructor
    return Excel::download($export, 'ExportEnquiries' . time() . rand(99, 9999) . '.csv');
}



}
