<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\MailSettings;
use Illuminate\Http\Request;

class MailSettingsController extends Controller
{
    public function postmailsettings(Request $request){
        $input=$request->all();
        // dd($input);

        $updatemail= MailSettings::find(1);
        $updatemail->port=$input['port'];
        $updatemail->name=ucwords(strtolower($input['name']));
        $updatemail->mailkey=$input['key'];
        $updatemail->update();
        session()->flash('messageType', 'success');
        session()->flash('message', 'Mail settings successfully updated');
        return redirect()->route('admin.adminsettings')->with('activeTab', 'pills-Mail');
    }
}
