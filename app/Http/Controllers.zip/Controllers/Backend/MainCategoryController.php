<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\MainCategory;
use App\Models\Subcategory;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use App\Exports\MainCategoryExport;
use Maatwebsite\Excel\Facades\Excel;
use PDF;

class MainCategoryController extends Controller
{
    public function maincategorylist()
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $maincategorylist = $this->getmaincategorylist();
            return view('admin.categories.maincategory.index', compact('maincategorylist'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function getmaincategorylist()
    {

        return MainCategory::orderBy('id', 'desc')->where('deleted_at', '0')->get();
    }

    public function addmaincategory()
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $icons = DB::table('configoptions')
            ->leftJoin('configs', 'configoptions.configid', '=', 'configs.id')
                ->select('configoptions.id as id', 'configoptions.optionname as optionname')            
                ->where('configs.slug', '=', 'icons')
                ->get();
            return view('admin.categories.maincategory.addmaincategory',compact('icons'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function postaddmaincategory(Request $request)
    {
        $input = $request->all();
        // echo "<pre>"; print_r($input); echo "</pre>"; exit;
        $imagePath = 'uploads/images/mainCategory';
        if ($request->hasFile('image')) {
            $logoimg = $request->file('image');
            $logoext = $logoimg->getClientOriginalExtension();
            $filename = rand(100000, 999999);
            $file = $filename . '.' . $logoext;
            $logoimg->move($imagePath, $file);
            $settinglink = $imagePath . '/' . $file;
            $input['image'] = $settinglink;
        }
        $result = $this->create($input);
        session()->flash('messageType', 'success');
        session()->flash('message', 'Main category successfully added');
        return redirect()->route('admin.maincategorylist');
    }

    public function create(array $input)
    {
        $maincategory = new MainCategory();
        $maincategory->icon = $input['icon'];
        $maincategory->name = ucwords(strtolower($input['name']));
        $maincategory->slug = $input['slug'];
        $maincategory->discription = ucfirst($input['discription']);
        $maincategory->image = $input['image'];
        $maincategory->created_at = Carbon::now();
        $maincategory->updated_at = Carbon::now();
        $maincategory->save();
        return 1;
    }

    public function softdeletemaincategory(Request $request)
    {
        $id = $request->input('id');
        $maincategory = MainCategory::find($id);
        // $maincategoryId = $maincategory->id;
        // echo "<pre> ---MC--- "; print_r($maincategoryId); echo "</pre>";
        $subcategory = Subcategory::where('maincategory', $id)->exists();
        // $subMaincategory = $subcategory->maincategory;
        // echo "<pre> ---SC--- "; print_r($subcategory); echo "</pre>"; exit;
        if ($subcategory) {
            session()->flash('messageType', 'error');
            session()->flash('message', 'Opps!, This Main categor assosiated with Sub category');
            return redirect()->route('admin.maincategorylist');
        } else {
            if (!$maincategory) {
                session()->flash('messageType', 'error');
                session()->flash('message', 'Main category not found.');
                return redirect()->route('admin.deletemaincategory');
            }
            $maincategory->deleted_at = '1';
            $maincategory->save();
            session()->flash('messageType', 'success');
            session()->flash('message', 'Main category temporarily deleted!');
            return redirect()->route('admin.maincategorylist');
        }
    }

    public function maincategorystatuschange(Request $request)
    {
        $id = $request->input('id');
        $maincategory = MainCategory::find($id);
        $maincategoryStatus = $maincategory->status;
        $subcategory = Subcategory::where('maincategory', $id)->exists();
        
        if ($subcategory && $maincategoryStatus == 'active') {
            return response()->json(["message" => 'Opps!, This Main category Assosiated with Sub category']);
        }
        else if ($maincategory) {
            $maincategory->status = $maincategory->status == 'inactive' ? 'active' : 'inactive';
            $maincategory->save();
            return response()->json(["message" => 'success', 'status' => $maincategory->status === 'active' ? 1 : 2]);
        }
        return response()->json(["message" => 'Failed to change']);
    }

    public function editmaincategory($id)
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $maincategoryInfo = MainCategory::find($id);
            $icons = DB::table('configoptions')
            ->select('configoptions.id', 'configoptions.optionname')
            ->leftJoin('configs', 'configoptions.configid', '=', 'configs.id')
            ->where('configs.slug', '=', 'icons')
            ->get();
            return view('admin.categories.maincategory.editmaincategory', compact('maincategoryInfo','icons'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function updatemaincategory(Request $request)
    {
        $input = $request->all();
        $destinationPath = 'uploads/images/maincategory';
        if ($request->file('image')) {
            $logoimg = $request->file('image');
            $logoext = $logoimg->getClientOriginalExtension();
            $filename = rand(100000, 999999);
            $file = $filename . '.' . $logoext;
            $logoimg->move($destinationPath, $file);
            $settinglink = $destinationPath . '/' . $file;
            $input['image'] = $settinglink;
        }
        $result = $this->update($input);
        if ($result == 1) {
            session()->flash('messageType', 'success');
            session()->flash('message', 'Main category successfully updated');
        }
        return redirect()->route('admin.maincategorylist');
    }

    public function update(array $input)
    {
        $maincategory = new MainCategory;
        $id = $input['maincategoryid'];
        $data = $maincategory->find($id);
        $data->icon = $input['icon'];
        $data->name = ucwords(strtolower($input['name']));
        $data->slug = $input['slug'];
        $data->discription = $input['discription'];
        if (isset($input['image']) && !empty($input['image'])) {
            if (file_exists($data->image)) {
                unlink($data->image);
            }
            $data->image = $input['image'];
        }
        if ($data->isDirty()) {
            $data->updated_at = Carbon::now();
            $data->save();
            return 1;
        } else {
            return 0;
        }
    }

    public function maincategorypdf()
    {
        $allmaincategory = MainCategory::where('deleted_at', '0')->get();
        $pdf = PDF::loadView('admin.categories.maincategory.exportmaincategory', compact('allmaincategory'));
        return $pdf->download('exportmaincategory' . time() . rand(99, 9999) . '.pdf');
    }

    public function maincategorycsv()
    {
        $allmaincategory = DB::table('maincategories')->where('deleted_at', '0')->get();
        $export = new MainCategoryExport($allmaincategory);
        return Excel::download($export, 'ExportMainCategory' . time() . rand(99, 9999) . '.csv');
    }

    public function checkName(Request $request)
    {
        if ($request->has('name')) {
            $name = $request->input('name');
            $id = $request->input('id', null);
            $query = DB::table('maincategories')->where('name', $name);
            if ($id !== null) {
                $query->where('id', '!=', $id);
            }
            $count = $query->count();
            $response = [];
            if ($count > 0) {
                $response['message'] = "Name is already in the database.";
            } else {
                $response['message'] = "";
            }
            return response()->json($response);
        }
    }

    public function maincategorytrashlist()
    {
        $maincategorylist = MainCategory::where('deleted_at', '1')->get();
        return view('admin.trash.categories.mainCategory.index', compact('maincategorylist'));
    }

    public function restore()
    {
        $id = request('id');
        $maincategory = MainCategory::find($id);
        if ($maincategory) {
            $maincategory->deleted_at = '0';
            $maincategory->save();
            session()->flash('messageType', 'success');
            session()->flash('message', 'Main category restore successfully!');
            return redirect()->route('admin.maincategorylist');
        }
    }
}
