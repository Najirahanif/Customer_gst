<?php

namespace App\Http\Controllers\Backend;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Gallery;
use App\Models\Project;
use App\Models\Post;
use App\Models\Contact;

class DashboardController extends Controller
{
    public function index(){
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $galleryCount = Gallery::count();
            $projectCount = Project::count();
            $postCount = Post::count();
            $contactCount = Contact::count();
            return view('admin.dashboard.index',compact('galleryCount','projectCount','postCount','contactCount'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }
    }

}
