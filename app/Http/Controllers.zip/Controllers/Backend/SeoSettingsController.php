<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\SeoSetting;
use Illuminate\Http\Request;

class SeoSettingsController extends Controller
{
    public function postseosetting(Request $request){
        $input=$request->all();
        // dd($input);
        $updateco= SeoSetting::find(1);
        $updateco->metatitle=$input['metatitle'];
        $updateco->keywords=$input['keywords'];
        $updateco->description=ucwords(strtolower($input['description']));
        $updateco->update();
        session()->flash('messageType', 'success');
        session()->flash('message', 'Co setting successfully updated');
        return redirect()->route('admin.adminsettings')->with('activeTab', 'pills-Co');
    }
}
