<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\Post;
use App\Exports\PostExport;
use View;
use PDF;

class PostController extends Controller {

    public function index() {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $postlist = $this->getpostlist();
            return view('admin.post.index', compact('postlist'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function getpostlist() {
        return Post::orderBy('id', 'desc')->where('deleted_at','0')->get();
    }

    public function addpost() {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $postoptions = DB::table('configoptions')
            ->leftJoin('configs', 'configoptions.configid', '=', 'configs.id')
                ->select('configoptions.id as id', 'configoptions.optionname as optionname')            
                ->where('configs.slug', '=', 'post-options')
                ->get();
            return view('admin.post.addpost',compact('postoptions'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function postaddpost(Request $request) {
        $input = $request->all();
        // dd($input);
        $postoption = isset($input['postoptions']) ? $input['postoptions'] : null;
        $serializedPostoption = is_array($postoption) ? implode(',', $postoption) : '';
        $imagePath = 'uploads/images/posts';
        if ($request->hasFile('image')) {
            $logoimg = $request->file('image');
            $logoext = $logoimg->getClientOriginalExtension();
            $filename = rand(100000, 999999);
            $file = $filename . '.' . $logoext;
            $logoimg->move($imagePath, $file);
            $settinglink = $imagePath . '/' . $file;
            $input['image'] = $settinglink;
        }
        $result = $this->create($input ,$serializedPostoption);
        // dd($input);
        session()->flash('messageType', 'success');
        session()->flash('message', 'post successfully added');
        return redirect()->route('admin.postlist');
    }

    public function create(array $input ,$serializedPostoption) {
        $post = new Post;
        $post->name = ucwords(strtolower($input['name']));
        $post->image = $input['image'];
        $post->postoptions = $serializedPostoption;
        $post->created_at = Carbon::now();
        $post->updated_at = Carbon::now();
        $post->save();
        return 1;
    }

    public function poststatuschange(Request $request)
    {
        $id = $request->input('id');
        $post = Post::find($id);
        if ($post) {
            $post->status = $post->status == 'inactive' ? 'active' : 'inactive';
            $post->save();
            return response()->json(["message"=>'success','status'=> $post->status ==='active'? 1 : 2 ]);
        }
        return response()->json(["message"=>'Failed to change']);
    }

    public function softdeletepost(Request $request) {
        $id = $request->input('id');
        $post = Post::find($id);
        if (!$post) {
            session()->flash('messageType', 'fail');
            session()->flash('message', 'post not found.');
            return redirect()->route('admin.postlist');
        }
            $post->deleted_at = '1';
            $post->save();
            session()->flash('messageType', 'success');
            session()->flash('message', 'post temporarily deleted!');
            return redirect()->route('admin.postlist');
    }

    public function editpost($id) {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $postInfo = Post::find($id);
            $postoptions = DB::table('configoptions')
            ->select('configoptions.id', 'configoptions.optionname')
            ->leftJoin('configs', 'configoptions.configid', '=', 'configs.id')
            ->where('configs.slug', '=', 'post-options')
            ->get();
            $postoption = explode(',', $postInfo->postoptions);
            return view('admin.post.editpost', compact('postInfo','postoptions','postoption'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function updatepost(Request $request) {
        $input = $request->all();
        $postoption = isset($input['postoptions']) ? $input['postoptions'] : null;
        $serializedPostoption = is_array($postoption) ? implode(',', $postoption) : '';
        $destinationPath = 'uploads/images/posts';
        if ($request->file('image')) {
            $logoimg = $request->file('image');
            $logoext = $logoimg->getClientOriginalExtension();
                $filename = rand(100000, 999999);
                $file = $filename . '.' . $logoext;
                $logoimg->move($destinationPath, $file);
                $settinglink = $destinationPath . '/' . $file;
                $input['image'] = $settinglink;
        }
        $result = $this->update($input,$serializedPostoption);
        if($result == 1) {
            session()->flash('messageType', 'success');
            session()->flash('message', 'post successfully updated');
        }
        return redirect()->route('admin.postlist');
    }

    public function update(array $input,$serializedPostoption) {
        $posts = new Post;
        $id = $input['postid'];
        $data = $posts->find($id);
        $data->name = ucfirst($input['name']);
        $data->postoptions = $serializedPostoption;
        if (isset($input['image']) && !empty($input['image'])) {
            if (file_exists($data->image)) {
                unlink($data->image);
            }
            $data->image = $input['image'];
        }
        if ($data->isDirty()) {
            $data->updated_at = Carbon::now();  
            $data->save();
            return 1;
        } else {
            return 0;
        }
    }

    public function postpdf() {
            $allpost = Post::where('deleted_at','0')->get();
            $pdf = PDF::loadView('admin.post.exportpost', compact('allpost'));
            return $pdf->download('exportpost' . time() . rand(99, 9999) .'.pdf');
    }

    public function postcsv() {
        $allpost = DB::table('posts')->where('deleted_at','0')->get();
        $export = new PostExport($allpost);
        return Excel::download($export, 'Exportpost' . time() . rand(99, 9999) . '.csv');
    }
    
    public function posttrashlist() {
            $postlist = Post::where('deleted_at', '1')->get();
            return view('admin.trash.post.index', compact('postlist'));
    }

    public function restore()
    {
        $id = request('id');
        $post = Post::find($id);
        if ($post) {
            $post->deleted_at = '0';
            $post->save();
            session()->flash('messageType', 'success');
            session()->flash('message', 'post restore successfully!');
            return redirect()->route('admin.postlist');
        }
    }

    public function checkName(Request $request) {
        if ($request->has('name')) {
            $name = $request->input('name');
            $id = $request->input('id', null); 
            $query = DB::table('posts')->where('name', $name);
            if ($id !== null) {
                $query->where('id', '!=', $id);
            }
            $count = $query->count();
            $response = [];
            if ($count > 0) {
                $response['message'] = "Name is already in the database.";
            } else {
                $response['message'] = "";
            }
            return response()->json($response);
        }
    }

}
