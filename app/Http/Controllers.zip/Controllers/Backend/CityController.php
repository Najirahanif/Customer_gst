<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\State;
use App\Models\City;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\CityExport;
use View;
use PDF;

class CityController extends Controller
{
    public function index() {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $city = $this->getcitylist();
            $alldata = DB::table('cities')
            ->join('states', 'cities.state', '=', 'states.id')
            ->select(
                'states.state as state',
                'cities.id as id',
                'cities.city as city',
                'cities.status as status'
                )
                ->where('cities.deleted_at', '0')
                ->orderBy('cities.id', 'desc')->get();
             return view('admin.master.city.index', compact('alldata'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }
           
    }

    public function getcitylist() {
        return City::orderBy('id', 'desc')->where('deleted_at','0')->get();
    }
    
    public function addcity() {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $stateshow= State::where('status','=','active')->get();
            return view('admin.master.city.addcity',compact('stateshow'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }
    }

    public function postaddcity(Request $request) {
        $input = $request->all();
       
        $result = $this->create($input);
        session()->flash('messageType', 'success');
        session()->flash('message', 'City successfully added');
        return redirect()->route('admin.citylist');
    }
    
    public function create(array $input) {
        $city = new City;
        $city->state = $input['state'];
        $city->city = ucwords(strtolower($input['city']));
        $city->created_at = Carbon::now();
        $city->updated_at = Carbon::now();
        $city->save();
        return 1;
    }

    public function statuschangestatus(Request $request)
    {
        $id = $request->input('id');
        $city = City::find($id);
        if ($city) {
            $city->status = $city->status == 'inactive' ? 'active' : 'inactive';
            $city->save();
            return response()->json(["message"=>'success','status'=> $city->status ==='active'? 1 : 2 ]);
        }
        return response()->json(["message"=>'Failed to change status']);
    }
    
    public function softdeletecity(Request $request) {
        $id = $request->input('id');
        $city = City::find($id);
        if (!$city) {
            session()->flash('messageType', 'fail');
            session()->flash('message', 'City not found.');
            return redirect()->route('admin.citylist');
        }
            $city->deleted_at = '1';
            $city->save();
            session()->flash('messageType', 'success');
            session()->flash('message', 'city temporarily deleted!');
            return redirect()->route('admin.citylist');
    }
 
    public function editcity($id) {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $cityinfo = City::find($id);
            $state= State::where('status','=','active')->get();
            return view('admin.master.city.editcity', compact('cityinfo','state'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }
    
    
    public function updatecity(Request $request) {
        $input = $request->all();
        $result = $this->update($input);
        if($result == 1) {
            session()->flash('messageType', 'success');
            session()->flash('message', 'City successfully updated');
        }
        return redirect()->route('admin.citylist');
    }
    
    public function update(array $input) {
        $id = $input['cityid'];
        $city = City::find($id);
    
        if ($city) {
            $city->state = $input['state'];
            $city->city = ucwords(strtolower($input['city']));
    
            if ($city->isDirty()) {
                $city->updated_at = Carbon::now();
                $city->save();
                return 1;
            } else {
                return 0;
            }
        } else {
            return 0; 
        }
    }   
          


    public function citypdf() {
        $city = City::where('deleted_at', '1')->get();
        $alldata = DB::table('cities')
        ->join('states', 'cities.state', '=', 'states.id')
        ->select(
            'states.state as state',
            'cities.id as id',
            'cities.city as city',
            'cities.status as status'
            )
            ->where('cities.deleted_at', '0')
            ->orderBy('cities.id', 'desc')->get();
       
        $pdf = PDF::loadView('admin.master.city.exportcity', compact('alldata'));
        return $pdf->download('exportcity' . time() . rand(99, 9999) .'.pdf');
    
    }    
    
    public function exportcitycsv() {
        $city = City::where('deleted_at', '1')->get();
        $alldata = DB::table('cities')
            ->join('states', 'cities.state', '=', 'states.id')
            ->select(
                'states.state as state',
                'cities.id as id',
                'cities.city as city',
                'cities.status as status'
                )
                ->where('cities.deleted_at', '0')
                ->orderBy('cities.id', 'desc')->get();
       
        $export = new CityExport($alldata);
        return Excel::download($export, 'exportcity' . time() . rand(99, 9999) . '.csv');
    }


    public function citytrashlist() {
        $city = City::where('deleted_at', '1')->get();
        $alldata = DB::table('cities')
            ->join('states', 'cities.state', '=', 'states.id')
            ->select(
                'states.state as state',
                'cities.id as id',
                'cities.city as city',
                'cities.status as status'
                )
                ->where('cities.deleted_at', '1')
                ->orderBy('cities.id', 'desc')->get();

        return view('admin.trash.master.city.index', compact('alldata'));
    }

    public function restorecity()
    {
        $id = request('id');
        $city = City::find($id);
        if ($city) {
            $city->deleted_at = '0';
            $city->save();
            session()->flash('messageType', 'success');
            session()->flash('message', 'City restore successfully!');
            return redirect()->route('admin.citylist');
        }
    }










}
