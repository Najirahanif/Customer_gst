<?php

namespace App\Http\Controllers\Backend;

use App\Exports\ServiceExport;
use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\MainCategory;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Carbon\Carbon;
use App\Models\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Maatwebsite\Excel\Facades\Excel;
use View;
use PDF;

class ServiceController extends Controller
{

    public function index()
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $alldata= $this->getservicelist();        
            return view('admin.service.index',compact('alldata'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }
    public function getservicelist(){
        return Service::orderBy('id','desc')->where('deleted_at','0')->get();
    }

    public function serviceadd()
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $icons = DB::table('configoptions')
            ->leftJoin('configs', 'configoptions.configid', '=', 'configs.id')
                ->select('configoptions.id as id', 'configoptions.optionname as optionname')            
                ->where('configs.slug', '=', 'icons')
                ->get();
            return view('admin.service.addservice',compact('icons'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }
 
    }

     public function checkName(Request $request) {
        if ($request->has('name')) {
            $name = $request->input('name');
            $id = $request->input('id', null); 
            $query = DB::table('services')->where('name', $name);
            if ($id !== null) {
                $query->where('id', '!=', $id);
            }
            $count = $query->count();
            $response = [];
            if ($count > 0) {
                $response['message'] = "Name is already in the database.";
            } else {
                $response['message'] = "";
            }
            return response()->json($response);
        }
    }

    public function postservice(Request $request){
        $input=$request->all();
        // echo "<pre>";print_r($input);exit;

        // image path
        $imagePath = 'uploads/images/services';
        if ($request->hasFile('image')) {
            $logoimg = $request->file('image');
            $logoext = $logoimg->getClientOriginalExtension();
            $filename = rand(100000, 999999);
            $file = $filename . '.' . $logoext;
            $logoimg->move($imagePath, $file);
            $settinglink = $imagePath . '/' . $file;
            $input['image'] = $settinglink;
        }
        $result = $this->create($input);
        session()->flash('messageType','success');
        session()->flash('message', 'service successfully added');
        return redirect()->route('admin.service.list');

    }

    public function create( array $input)
    {
        $service=new Service;
        $service->icon=$input['icon'];
        $service->name = ucwords(strtolower($input['name']));
        $service->slug = $input['slug'];
        $service->description = ucwords(strtolower($input['description']));
        $service->image = $input['image'];
        $service->created_at = Carbon::now();
        $service->updated_at = Carbon::now();
        $service->save();
        return 1;

    }

    public function statuschangeservice(Request $request){
        $id=$request->input('id');
        $service=Service::find($id);
        $servicestatus=$service->status;
        $service->status=$service->status == 'inactive' ? 'active' : 'inactive';
        $service->save();
        return response()->json(["message"=>'success','status'=>$service->status == 'active' ? 1 :2]);        
    }

    // delete temperorily

    public function deleteservice( Request $request){
       
        $id=$request->input('id');
        $service=Service::find($id);

            $service->deleted_at = '1';
            $service->save();
            session()->flash('messageType', 'success');
            session()->flash('message', 'service temporarily deleted!');
            return redirect()->route('admin.service.list');  
        
               
    }


    
    // listing the deleted items in trash
    
    public function trashlistservice(){

        $alldata = Service::where('deleted_at','1')->get();

        return view('admin.trash.service.index', compact('alldata'));
    }
    // restore the deleted 

    public function servicerestore(Request $request){
        $id = request('id');
        $service = Service::find($id);
        // dd($service);
        if ($service) {
            $service->deleted_at = '0';
            $service->save();
            session()->flash('messageType', 'success');
            session()->flash('message', 'service restored successfully!');
            return redirect()->route('admin.service.list');
        }
    }


    // edit function
    public function editservice($id)
    {
        if (Session::has('adminname') && Session::get('logintype') === 'admin') {
            $serviceinfo=Service::find($id);
            $icons = DB::table('configoptions')
            ->leftJoin('configs', 'configoptions.configid', '=', 'configs.id')
                ->select('configoptions.id as id', 'configoptions.optionname as optionname')            
                ->where('configs.slug', '=', 'icons')
                ->get();
            // dd($maincategoryshow);
            return view('admin.service.editservice',compact('serviceinfo','icons'));
        } else {
            Session::flash('messageType', 'error');
            Session::flash('message', 'Login to your Account');
            return redirect()->route('admin.login');
        }

    }

    public function postupdateservice(Request $request)
    {
        $input = $request->all();
        $destinationPath = 'uploads/images/services';

        if ($request->hasFile('image')) {
            $logoimg = $request->file('image');
            $logoext = $logoimg->getClientOriginalExtension();
            $filename = rand(100000, 999999);
            $file = $filename . '.' . $logoext;
            $logoimg->move($destinationPath, $file);
            $settinglink = $destinationPath . '/' . $file;
            $input['image'] = $settinglink;
        }

        $result = $this->update($input);

        if ($result == 1) {
            session()->flash('messageType', 'success');
            session()->flash('message', 'Service successfully updated');
        }

        return redirect()->route('admin.service.list');
    }

    public function update(array $input)
{
    $id = $input['serviceid'];
    $data = Service::find($id);

    if (!$data) {
        // Handle case where service with given ID is not found
        return 0;
    }

    $data->icon = $input['icon'];
    $data->name = ucfirst(strtolower($input['name']));
    $data->slug = $input['slug'];
    $data->description = ucwords($input['description']);

    if (array_key_exists('image', $input) && $input['image']) {
        if (file_exists($data->image)) {
            unlink($data->image);
        }
        $data->image = $input['image'];
    }

    if ($data->isDirty()) {
        $data->updated_at = Carbon::now();
        $data->save();
        return 1;
    } else {
        return 0;
    }
}


    // rendeering pdf 
    public function servicepdf(){
        $allservice = Service::where('deleted_at','0')->get();
            $pdf = PDF::loadView('admin.service.exportservice', compact('allservice'));
            return $pdf->download('export-service' . time() . rand(99, 9999) .'.pdf');
    }

    // rendering excel
    public function servicecsv(){
        $allservice =Service::where('deleted_at','0')->get();
        $export = new ServiceExport($allservice);
        return Excel::download($export, 'Exportservice' . time() . rand(99, 9999) . '.csv');
    }
}

