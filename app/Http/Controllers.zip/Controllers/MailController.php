<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Mail;
use App\Mail\ContactFormMail;
use App\Mail\TestEmail;
use Illuminate\Http\Request;

class MailController extends Controller
{

    // public function sendContactMail(Request $request){
    //     $contact_data  = [];
    //     $contact_data['name'] = $request->input('name');
    //     $contact_data['email'] = $request->input('email');
    //     $contact_data['message'] = $request->input('message');

    //     Mail::to('tharasasi333@gmail.com')->send(new ContactFormMail($contact_data));

    //     return redirect()->back()->withSuccess('Email has been sent!');
    // }
    
    
    // public function sendContactMail(Request $request) {
    //     // $contact_data  = [
    //     //     'name' => $request->input('name'),
    //     //     'email' => $request->input('email'),
    //     //     'message' => $request->input('message')
    //     // ];
    //     $mailData  = [];
    //             $mailData  = [
    //         'name' => 'name',
    //     ];
    
    //     // Specify the sender using the 'from' method
    //     Mail::to('tharasasi333@gmail.com')
    //     ->send(new TestEmail($mailData));
    // dd('Email has been sent!');
    //     // return redirect()->back()->withSuccess('Email has been sent!');
    // }
    
    public function sendContactMail(Request $request)
    {
        $mailData = [
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'message' => $request->input('message')
        ];
    
        $fromEmail = 'tharasasi333@gmail.com';
        $fromName = "sasi";
        $subject = "Thank you for subscribing to our newsletter";
    
        $viewName = view()->exists('emails.contact_mail') ? 'emails.contact_mail' : 'emails.contact_mail';
    
        Mail::send($viewName, $mailData, function ($message) use ($request, $subject, $fromEmail, $fromName) {
            $message->to($request->input('email'))
                ->subject($subject)
                ->from($fromEmail, $fromName);
        });
    dd('success');
       
    }
    
    
    
}
